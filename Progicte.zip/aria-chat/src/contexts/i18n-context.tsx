'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { translations, type TranslationKey } from '@/lib/i18n/translations';
import type { Language } from '@/types/database';

interface I18nContextValue {
  language: Language;
  dir: 'ltr' | 'rtl';
  setLanguage: (lang: Language) => void;
  t: <K extends TranslationKey>(key: K) => (typeof translations)['en'][K];
}

const I18nContext = createContext<I18nContextValue | null>(null);

export function I18nProvider({
  children,
  initialLanguage = 'en'
}: {
  children: React.ReactNode;
  initialLanguage?: Language;
}) {
  const [language, setLanguageState] = useState<Language>(initialLanguage);

  useEffect(() => {
    const stored = window.localStorage.getItem('aria-language') as Language | null;
    if (stored === 'en' || stored === 'ar') setLanguageState(stored);
  }, []);

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang);
    window.localStorage.setItem('aria-language', lang);
  }, []);

  const t = useCallback(
    <K extends TranslationKey>(key: K) => translations[language][key],
    [language]
  );

  const value = useMemo(
    () => ({ language, dir: (language === 'ar' ? 'rtl' : 'ltr') as 'ltr' | 'rtl', setLanguage, t }),
    [language, setLanguage, t]
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n must be used within I18nProvider');
  return ctx;
}
