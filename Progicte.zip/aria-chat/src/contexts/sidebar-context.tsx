'use client';

import { createContext, useContext, useEffect, useState } from 'react';
import { useMediaQuery } from '@/hooks/use-media-query';

interface SidebarContextValue {
  /** Desktop: sidebar collapsed to icon rail. Mobile: irrelevant. */
  collapsed: boolean;
  toggleCollapsed: () => void;
  /** Mobile: drawer open/closed. */
  mobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
  isMobile: boolean;
}

const SidebarContext = createContext<SidebarContextValue | null>(null);

export function SidebarProvider({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const isMobile = useMediaQuery('(max-width: 767px)');

  useEffect(() => {
    const stored = window.localStorage.getItem('aria-sidebar-collapsed');
    if (stored === '1') setCollapsed(true);
  }, []);

  useEffect(() => {
    if (!isMobile) setMobileOpen(false);
  }, [isMobile]);

  const toggleCollapsed = () => {
    setCollapsed((prev) => {
      window.localStorage.setItem('aria-sidebar-collapsed', prev ? '0' : '1');
      return !prev;
    });
  };

  return (
    <SidebarContext.Provider value={{ collapsed, toggleCollapsed, mobileOpen, setMobileOpen, isMobile }}>
      {children}
    </SidebarContext.Provider>
  );
}

export function useSidebar() {
  const ctx = useContext(SidebarContext);
  if (!ctx) throw new Error('useSidebar must be used within SidebarProvider');
  return ctx;
}
