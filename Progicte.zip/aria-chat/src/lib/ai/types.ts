export interface ProviderMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  /** Data URLs for images attached to this message, if the model supports vision. */
  images?: string[];
}

export interface StreamChunk {
  /** Incremental text to append to the assistant message. */
  delta?: string;
  /** Set on the final chunk. */
  done?: boolean;
  /** Set if the provider returned an error mid-stream. */
  error?: string;
}

export interface ModelDefinition {
  id: 'fast' | 'balanced' | 'advanced';
  label: string;
  description: string;
  provider: 'openai' | 'gemini' | 'openai-compatible';
  /** The underlying model name sent to the provider's API. */
  apiModel: string;
  supportsImages: boolean;
  /** True once we've confirmed the required env var is present. */
  available: boolean;
  missingEnvVar?: string;
}

export interface ChatProvider {
  streamChat(messages: ProviderMessage[], apiModel: string): AsyncGenerator<StreamChunk>;
}
