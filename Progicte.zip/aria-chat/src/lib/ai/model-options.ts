import { getModelDefinitions } from './registry';
import type { ModelOption } from '@/components/chat/model-selector';

/** Maps server-only ModelDefinition[] down to the plain ModelOption[] shape client components receive as props. */
export function getModelOptions(): ModelOption[] {
  return getModelDefinitions().map((m) => ({
    id: m.id,
    label: m.label,
    description: m.description,
    available: m.available,
    missingEnvVar: m.missingEnvVar,
    supportsImages: m.supportsImages
  }));
}
