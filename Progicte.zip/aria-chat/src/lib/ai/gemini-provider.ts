import type { ChatProvider, ProviderMessage, StreamChunk } from './types';

/** Google Gemini API (generateContent / streamGenerateContent over REST). */
export class GeminiProvider implements ChatProvider {
  constructor(private apiKey: string) {}

  async *streamChat(messages: ProviderMessage[], apiModel: string): AsyncGenerator<StreamChunk> {
    const systemMessages = messages.filter((m) => m.role === 'system');
    const turns = messages.filter((m) => m.role !== 'system');

    const contents = turns.map((m) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [
        { text: m.content },
        ...(m.images ?? []).map((dataUrl) => {
          const match = /^data:(.+);base64,(.*)$/.exec(dataUrl);
          return match
            ? { inline_data: { mime_type: match[1], data: match[2] } }
            : { text: '' };
        })
      ].filter((p) => !('text' in p) || p.text !== '')
    }));

    const body: Record<string, unknown> = { contents };
    if (systemMessages.length) {
      body.systemInstruction = { parts: [{ text: systemMessages.map((m) => m.content).join('\n') }] };
    }

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${apiModel}:streamGenerateContent?alt=sse&key=${this.apiKey}`;

    let res: Response;
    try {
      res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
    } catch {
      yield { error: 'Could not reach the AI provider. Check your network connection and try again.' };
      return;
    }

    if (!res.ok || !res.body) {
      const text = await res.text().catch(() => '');
      yield { error: describeGeminiError(res.status, text) };
      return;
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith('data:')) continue;
        const payload = trimmed.slice(5).trim();
        if (!payload) continue;
        try {
          const json = JSON.parse(payload);
          const delta = json.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? '').join('');
          if (delta) yield { delta };
        } catch {
          // Ignore malformed keep-alive lines.
        }
      }
    }
    yield { done: true };
  }
}

function describeGeminiError(status: number, body: string): string {
  if (status === 400) return 'Gemini rejected the request — the prompt or attachment may be malformed.';
  if (status === 403) return 'The Gemini API key is invalid or missing. Check GEMINI_API_KEY in your environment.';
  if (status === 429) return 'Gemini rate limit reached. Wait a moment and try again.';
  if (status >= 500) return 'Gemini is temporarily unavailable. Try again in a moment.';
  try {
    const parsed = JSON.parse(body);
    if (parsed?.error?.message) return `Gemini error: ${parsed.error.message}`;
  } catch {
    // fall through
  }
  return `Gemini request failed (status ${status}).`;
}
