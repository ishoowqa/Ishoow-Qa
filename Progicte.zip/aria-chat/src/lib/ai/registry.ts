import { OpenAIProvider } from './openai-provider';
import { GeminiProvider } from './gemini-provider';
import type { ChatProvider, ModelDefinition, ModelId } from './types';

/**
 * The three model "tiers" shown in the UI. Swap `apiModel` values or add
 * more entries here to change what's on offer — nothing else in the app
 * needs to know about specific model names.
 */
function buildModelDefinitions(): ModelDefinition[] {
  const hasOpenAI = !!process.env.OPENAI_API_KEY;
  const hasGemini = !!process.env.GEMINI_API_KEY;
  const hasCompatible = !!(process.env.OPENAI_COMPATIBLE_BASE_URL && process.env.OPENAI_COMPATIBLE_API_KEY);

  return [
    {
      id: 'fast',
      label: 'Fast',
      description: 'Quick, lightweight responses for everyday questions.',
      provider: 'openai',
      apiModel: 'gpt-4o-mini',
      supportsImages: true,
      available: hasOpenAI,
      missingEnvVar: hasOpenAI ? undefined : 'OPENAI_API_KEY'
    },
    {
      id: 'balanced',
      label: 'Balanced',
      description: 'A strong default for most conversations.',
      provider: 'gemini',
      apiModel: 'gemini-2.0-flash',
      supportsImages: true,
      available: hasGemini,
      missingEnvVar: hasGemini ? undefined : 'GEMINI_API_KEY'
    },
    {
      id: 'advanced',
      label: 'Advanced',
      description: 'Slower, more capable model for complex tasks.',
      provider: hasCompatible ? 'openai-compatible' : 'openai',
      apiModel: hasCompatible ? process.env.OPENAI_COMPATIBLE_MODEL || 'default' : 'gpt-4o',
      supportsImages: !hasCompatible,
      available: hasCompatible || hasOpenAI,
      missingEnvVar: hasCompatible || hasOpenAI ? undefined : 'OPENAI_API_KEY'
    }
  ];
}

export function getModelDefinitions(): ModelDefinition[] {
  return buildModelDefinitions();
}

export function getModelById(id: string): ModelDefinition | undefined {
  return buildModelDefinitions().find((m) => m.id === id);
}

export function getProviderFor(model: ModelDefinition): ChatProvider {
  switch (model.provider) {
    case 'openai':
      return new OpenAIProvider(process.env.OPENAI_API_KEY!);
    case 'gemini':
      return new GeminiProvider(process.env.GEMINI_API_KEY!);
    case 'openai-compatible':
      return new OpenAIProvider(process.env.OPENAI_COMPATIBLE_API_KEY!, process.env.OPENAI_COMPATIBLE_BASE_URL!);
  }
}

export const DEFAULT_MODEL: ModelId = 'balanced';
