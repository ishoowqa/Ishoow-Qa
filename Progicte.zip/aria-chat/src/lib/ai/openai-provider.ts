import type { ChatProvider, ProviderMessage, StreamChunk } from './types';

/**
 * Works against api.openai.com or any OpenAI-compatible endpoint
 * (Groq, Together, OpenRouter, a local Ollama server, etc) — pass a
 * different baseUrl/apiKey to reuse this for the "openai-compatible" slot.
 */
export class OpenAIProvider implements ChatProvider {
  constructor(
    private apiKey: string,
    private baseUrl: string = 'https://api.openai.com/v1'
  ) {}

  async *streamChat(messages: ProviderMessage[], apiModel: string): AsyncGenerator<StreamChunk> {
    const body = {
      model: apiModel,
      stream: true,
      messages: messages.map((m) => {
        if (m.images?.length) {
          return {
            role: m.role,
            content: [
              { type: 'text', text: m.content },
              ...m.images.map((url) => ({ type: 'image_url', image_url: { url } }))
            ]
          };
        }
        return { role: m.role, content: m.content };
      })
    };

    let res: Response;
    try {
      res = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${this.apiKey}`
        },
        body: JSON.stringify(body)
      });
    } catch {
      yield { error: 'Could not reach the AI provider. Check your network connection and try again.' };
      return;
    }

    if (!res.ok || !res.body) {
      const text = await res.text().catch(() => '');
      yield { error: describeOpenAIError(res.status, text) };
      return;
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith('data:')) continue;
        const payload = trimmed.slice(5).trim();
        if (payload === '[DONE]') {
          yield { done: true };
          return;
        }
        try {
          const json = JSON.parse(payload);
          const delta = json.choices?.[0]?.delta?.content;
          if (delta) yield { delta };
        } catch {
          // Ignore malformed keep-alive lines.
        }
      }
    }
    yield { done: true };
  }
}

function describeOpenAIError(status: number, body: string): string {
  if (status === 401) return 'The OpenAI API key is invalid or missing. Check OPENAI_API_KEY in your environment.';
  if (status === 429) return 'OpenAI rate limit reached. Wait a moment and try again.';
  if (status >= 500) return 'OpenAI is temporarily unavailable. Try again in a moment.';
  try {
    const parsed = JSON.parse(body);
    if (parsed?.error?.message) return `OpenAI error: ${parsed.error.message}`;
  } catch {
    // fall through
  }
  return `OpenAI request failed (status ${status}).`;
}
