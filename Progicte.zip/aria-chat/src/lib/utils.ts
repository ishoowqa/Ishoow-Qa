import { clsx, type ClassValue } from 'clsx';

import type { Attachment } from '@/types/database';

export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}

export const MAX_FILE_SIZE_MB = 20;
export const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;

export const ACCEPTED_FILE_TYPES = [
  'image/png',
  'image/jpeg',
  'image/webp',
  'image/gif',
  'application/pdf',
  'text/plain',
  'text/csv'
];

export function isImageType(type: string) {
  return type.startsWith('image/');
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function formatTimestamp(iso: string, locale: string): string {
  try {
    return new Intl.DateTimeFormat(locale, { hour: 'numeric', minute: '2-digit' }).format(new Date(iso));
  } catch {
    return '';
  }
}

/** Buckets a conversation's updated_at into a sidebar section key. */
export function dateBucket(iso: string): 'today' | 'yesterday' | 'previous7' | 'older' {
  const date = new Date(iso);
  const now = new Date();
  const startOfDay = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  const diffDays = Math.round((startOfDay(now) - startOfDay(date)) / 86400000);

  if (diffDays <= 0) return 'today';
  if (diffDays === 1) return 'yesterday';
  if (diffDays <= 7) return 'previous7';
  return 'older';
}

export function truncate(text: string, max: number): string {
  return text.length > max ? `${text.slice(0, max).trimEnd()}…` : text;
}

/** Derives a short conversation title from the first user message. */
export function deriveTitle(firstMessage: string): string {
  const cleaned = firstMessage.replace(/\s+/g, ' ').trim();
  return truncate(cleaned, 48) || 'New chat';
}

export function generateId(): string {
  return crypto.randomUUID();
}

/** Strips client-only fields (progress, previewDataUrl, etc.) before an attachment is persisted to the database. */
export function toPersistableAttachment(a: Attachment): Pick<Attachment, 'id' | 'name' | 'type' | 'size' | 'url' | 'storage_path'> {
  return { id: a.id, name: a.name, type: a.type, size: a.size, url: a.url, storage_path: a.storage_path };
}
