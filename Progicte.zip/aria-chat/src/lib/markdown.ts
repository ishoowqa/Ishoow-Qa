import { Marked } from 'marked';
import hljs from 'highlight.js/lib/core';

// Register a focused set of common languages to keep the bundle lean.
import javascript from 'highlight.js/lib/languages/javascript';
import typescript from 'highlight.js/lib/languages/typescript';
import python from 'highlight.js/lib/languages/python';
import xml from 'highlight.js/lib/languages/xml';
import css from 'highlight.js/lib/languages/css';
import json from 'highlight.js/lib/languages/json';
import bash from 'highlight.js/lib/languages/bash';
import sql from 'highlight.js/lib/languages/sql';
import yaml from 'highlight.js/lib/languages/yaml';
import java from 'highlight.js/lib/languages/java';
import cpp from 'highlight.js/lib/languages/cpp';
import go from 'highlight.js/lib/languages/go';
import rust from 'highlight.js/lib/languages/rust';
import markdown from 'highlight.js/lib/languages/markdown';

hljs.registerLanguage('javascript', javascript);
hljs.registerLanguage('js', javascript);
hljs.registerLanguage('typescript', typescript);
hljs.registerLanguage('ts', typescript);
hljs.registerLanguage('jsx', javascript);
hljs.registerLanguage('tsx', typescript);
hljs.registerLanguage('python', python);
hljs.registerLanguage('py', python);
hljs.registerLanguage('html', xml);
hljs.registerLanguage('xml', xml);
hljs.registerLanguage('css', css);
hljs.registerLanguage('json', json);
hljs.registerLanguage('bash', bash);
hljs.registerLanguage('sh', bash);
hljs.registerLanguage('shell', bash);
hljs.registerLanguage('sql', sql);
hljs.registerLanguage('yaml', yaml);
hljs.registerLanguage('yml', yaml);
hljs.registerLanguage('java', java);
hljs.registerLanguage('cpp', cpp);
hljs.registerLanguage('c', cpp);
hljs.registerLanguage('go', go);
hljs.registerLanguage('rust', rust);
hljs.registerLanguage('markdown', markdown);
hljs.registerLanguage('md', markdown);

function highlightCode(code: string, lang: string): string {
  const language = hljs.getLanguage(lang) ? lang : undefined;
  try {
    return language ? hljs.highlight(code, { language }).value : hljs.highlightAuto(code).value;
  } catch {
    return escapeHtml(code);
  }
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

const marked = new Marked({ breaks: true, gfm: true });

// Fenced code blocks get a header (language label + copy button) that the
// client hydrates with working copy behavior via event delegation in
// MessageContent. This fully replaces marked's default code renderer, so
// there's no double-highlighting risk from a separate highlighting plugin.
marked.use({
  renderer: {
    code(this: unknown, token: { text: string; lang?: string }) {
      const lang = (token.lang || '').trim().split(/\s+/)[0] || 'text';
      const highlighted = highlightCode(token.text, lang);
      const escapedRaw = encodeURIComponent(token.text);
      return `<div class="code-block" data-code="${escapedRaw}">
  <div class="code-block-header">
    <span class="code-block-lang">${escapeHtml(lang)}</span>
    <button type="button" class="code-copy-btn" data-copy-code aria-label="Copy code">Copy</button>
  </div>
  <pre><code class="hljs language-${escapeHtml(lang)}">${highlighted}</code></pre>
</div>`;
    }
  }
});

/** Renders markdown to sanitized-enough HTML for chat messages. */
export function renderMarkdown(content: string): string {
  const html = marked.parse(content, { async: false }) as string;
  return sanitizeHtml(html);
}

/**
 * Minimal allow-list sanitizer: strips script/style/iframe/object/embed
 * tags and inline event-handler attributes. Runs on server and client.
 */
function sanitizeHtml(html: string): string {
  return html
    .replace(/<\/(script|style|iframe|object|embed)>/gi, '')
    .replace(/<(script|style|iframe|object|embed)[^>]*>[\s\S]*?<\/\1>/gi, '')
    .replace(/<(script|style|iframe|object|embed)[^>]*\/?>(?!<\/\1>)/gi, '')
    .replace(/\son\w+="[^"]*"/gi, '')
    .replace(/\son\w+='[^']*'/gi, '')
    .replace(/href="javascript:[^"]*"/gi, 'href="#"');
}
