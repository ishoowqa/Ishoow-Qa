export type Theme = 'light' | 'dark' | 'system';
export type Language = 'en' | 'ar';
export type MessageRole = 'user' | 'assistant' | 'system';
export type ModelId = 'fast' | 'balanced' | 'advanced';

export interface UserSettings {
  user_id: string;
  theme: Theme;
  language: Language;
  enter_to_send: boolean;
  show_timestamps: boolean;
  save_chat_history: boolean;
  default_model: ModelId;
  display_name: string | null;
  updated_at: string;
}

export interface Conversation {
  id: string;
  user_id: string;
  title: string;
  model: ModelId;
  pinned: boolean;
  created_at: string;
  updated_at: string;
}

export interface Attachment {
  id: string;
  name: string;
  type: string;
  size: number;
  url?: string;
  storage_path?: string;
  status?: 'uploading' | 'done' | 'error';
  progress?: number;
  errorMessage?: string;
  /** Present for images so we can render an inline preview before upload completes. */
  previewDataUrl?: string;
}

export interface ChatMessage {
  id: string;
  conversation_id: string;
  user_id: string;
  role: MessageRole;
  content: string;
  attachments: Attachment[];
  model?: ModelId | null;
  liked?: boolean | null;
  error?: string | null;
  created_at: string;
  /** Client-only: true while a response is still streaming in. */
  streaming?: boolean;
}

export interface Database {
  public: {
    Tables: {
      user_settings: {
        Row: UserSettings;
        Insert: Partial<UserSettings> & { user_id: string };
        Update: Partial<UserSettings>;
      };
      conversations: {
        Row: Conversation;
        Insert: Partial<Conversation> & { user_id: string };
        Update: Partial<Conversation>;
      };
      messages: {
        Row: ChatMessage;
        Insert: Partial<ChatMessage> & { conversation_id: string; user_id: string; role: MessageRole };
        Update: Partial<ChatMessage>;
      };
      attachments: {
        Row: {
          id: string;
          message_id: string | null;
          user_id: string;
          file_name: string;
          file_type: string;
          file_size: number;
          storage_path: string;
          created_at: string;
        };
        Insert: Record<string, unknown>;
        Update: Record<string, unknown>;
      };
    };
  };
}
