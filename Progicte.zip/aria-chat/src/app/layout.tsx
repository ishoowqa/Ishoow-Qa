import type { Metadata, Viewport } from 'next';
import { Inter, IBM_Plex_Sans_Arabic, JetBrains_Mono } from 'next/font/google';
import { createClient } from '@/lib/supabase/server';
import { Providers } from '@/components/providers';
import type { Language, Theme } from '@/types/database';
import './globals.css';

const inter = Inter({ subsets: ['latin'], variable: '--font-sans', display: 'swap' });
const arabic = IBM_Plex_Sans_Arabic({
  subsets: ['arabic'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-arabic',
  display: 'swap'
});
const mono = JetBrains_Mono({ subsets: ['latin'], variable: '--font-mono', display: 'swap' });

export const metadata: Metadata = {
  title: 'Aria — Your AI assistant',
  description: 'A fast, private AI chat assistant with conversation history, voice input, and file attachments.'
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#faf9f7' },
    { media: '(prefers-color-scheme: dark)', color: '#141311' }
  ]
};

// Runs before hydration so the correct theme/direction paint immediately —
// avoids a flash of the wrong theme or LTR-then-RTL layout shift.
const themeInitScript = `
(function () {
  try {
    var theme = localStorage.getItem('aria-theme') || 'system';
    var resolved = theme === 'system'
      ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
      : theme;
    if (resolved === 'dark') document.documentElement.classList.add('dark');
    var lang = localStorage.getItem('aria-language') || 'en';
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  } catch (e) {}
})();
`;

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  let initialTheme: Theme = 'system';
  let initialLanguage: Language = 'en';

  if (user) {
    const { data: settings } = await supabase
      .from('user_settings')
      .select('theme, language')
      .eq('user_id', user.id)
      .single();
    if (settings?.theme) initialTheme = settings.theme;
    if (settings?.language) initialLanguage = settings.language;
  }

  return (
    <html lang={initialLanguage} dir={initialLanguage === 'ar' ? 'rtl' : 'ltr'} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeInitScript }} />
      </head>
      <body className={`${inter.variable} ${arabic.variable} ${mono.variable} font-sans antialiased`}>
        <Providers initialUser={user} initialTheme={initialTheme} initialLanguage={initialLanguage}>
          {children}
        </Providers>
      </body>
    </html>
  );
}
