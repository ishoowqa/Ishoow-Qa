'use client';

import { useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';
import { useI18n } from '@/contexts/i18n-context';
import { AuthShell } from '@/components/auth/auth-shell';
import { Input, Label, FieldError } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { CheckIcon } from '@/components/ui/icons';

export default function ForgotPasswordPage() {
  const { t } = useI18n();
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const supabase = createClient();
    const { error: resetError } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`
    });

    setLoading(false);
    if (resetError) {
      setError(resetError.message);
      return;
    }
    setSent(true);
  };

  if (sent) {
    return (
      <AuthShell title={t('resetPassword')}>
        <div className="flex flex-col items-center gap-3 py-4 text-center">
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/15 text-accent">
            <CheckIcon className="h-5 w-5" />
          </span>
          <p className="text-sm text-ink">{t('resetLinkSent')}</p>
          <Link href="/login" className="text-sm font-medium text-accent hover:underline">
            {t('backToLogin')}
          </Link>
        </div>
      </AuthShell>
    );
  }

  return (
    <AuthShell
      title={t('resetPassword')}
      subtitle="Enter your email and we'll send you a link to reset your password."
      footer={
        <Link href="/login" className="font-medium text-accent hover:underline">
          {t('backToLogin')}
        </Link>
      }
    >
      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        <div>
          <Label htmlFor="email">{t('email')}</Label>
          <Input
            id="email"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <FieldError>{error}</FieldError>
        <Button type="submit" variant="primary" className="w-full" loading={loading}>
          {t('sendResetLink')}
        </Button>
      </form>
    </AuthShell>
  );
}
