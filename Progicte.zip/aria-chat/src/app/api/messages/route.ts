import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { deriveTitle } from '@/lib/utils';
import type { Attachment } from '@/types/database';

// POST /api/messages — persists a single message (user or assistant) and,
// if this is the conversation's first user message, derives a title from it.
export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });

  const body = await request.json().catch(() => ({}));
  const { conversationId, role, content, attachments, model, error: messageError } = body as {
    conversationId?: string;
    role?: 'user' | 'assistant' | 'system';
    content?: string;
    attachments?: Attachment[];
    model?: string;
    error?: string;
  };

  if (!conversationId || !role || (content === undefined && !messageError)) {
    return NextResponse.json({ error: 'conversationId, role, and content are required' }, { status: 400 });
  }

  const { data: conversation } = await supabase
    .from('conversations')
    .select('id, title')
    .eq('id', conversationId)
    .eq('user_id', user.id)
    .single();

  if (!conversation) return NextResponse.json({ error: 'Conversation not found' }, { status: 404 });

  const { data: message, error } = await supabase
    .from('messages')
    .insert({
      conversation_id: conversationId,
      user_id: user.id,
      role,
      content: content ?? '',
      attachments: attachments ?? [],
      model: model ?? null,
      error: messageError ?? null
    })
    .select('*')
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  if (role === 'user' && conversation.title === 'New chat' && content) {
    await supabase.from('conversations').update({ title: deriveTitle(content) }).eq('id', conversationId);
  }

  return NextResponse.json({ message });
}

// DELETE /api/messages?conversationId=…&afterCreatedAt=ISO
// Removes every message created at or after the given timestamp — used
// when editing a user message or regenerating a response, so stale
// downstream turns don't linger in the transcript.
export async function DELETE(request: Request) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const conversationId = searchParams.get('conversationId');
  const afterCreatedAt = searchParams.get('afterCreatedAt');
  const messageId = searchParams.get('id');

  if (messageId) {
    const { error } = await supabase.from('messages').delete().eq('id', messageId).eq('user_id', user.id);
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    return NextResponse.json({ success: true });
  }

  if (!conversationId || !afterCreatedAt) {
    return NextResponse.json({ error: 'conversationId and afterCreatedAt (or id) are required' }, { status: 400 });
  }

  const { error } = await supabase
    .from('messages')
    .delete()
    .eq('conversation_id', conversationId)
    .eq('user_id', user.id)
    .gte('created_at', afterCreatedAt);

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ success: true });
}
