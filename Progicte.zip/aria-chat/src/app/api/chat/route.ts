import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { getModelById, getProviderFor } from '@/lib/ai/registry';
import type { ProviderMessage } from '@/lib/ai/types';
import type { Attachment } from '@/types/database';

export const maxDuration = 60;

const SYSTEM_PROMPT =
  'You are Aria, a helpful, concise AI assistant embedded in a chat product. ' +
  'Format responses in Markdown when it helps readability (lists, tables, code blocks with a language tag). ' +
  'Be direct and avoid unnecessary preamble.';

// POST /api/chat — streams an assistant reply for a conversation and, once
// the stream finishes, persists the full response as a message row.
// The user's message must already be saved via POST /api/messages before
// calling this route.
export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });

  const body = await request.json().catch(() => ({}));
  const { conversationId, modelId } = body as { conversationId?: string; modelId?: string };

  if (!conversationId || !modelId) {
    return NextResponse.json({ error: 'conversationId and modelId are required' }, { status: 400 });
  }

  const model = getModelById(modelId);
  if (!model) return NextResponse.json({ error: 'Unknown model' }, { status: 400 });
  if (!model.available) {
    return NextResponse.json(
      { error: `This model isn\u2019t configured yet. Set ${model.missingEnvVar} in your environment to enable it.` },
      { status: 503 }
    );
  }

  const { data: conversation } = await supabase
    .from('conversations')
    .select('id')
    .eq('id', conversationId)
    .eq('user_id', user.id)
    .single();
  if (!conversation) return NextResponse.json({ error: 'Conversation not found' }, { status: 404 });

  const { data: history, error: historyError } = await supabase
    .from('messages')
    .select('role, content, attachments')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: true });

  if (historyError) return NextResponse.json({ error: historyError.message }, { status: 500 });
  if (!history || history.length === 0) {
    return NextResponse.json({ error: 'No messages to respond to' }, { status: 400 });
  }

  // Both providers accept inline base64 image data (OpenAI's image_url.url
  // and Gemini's inline_data both take data URLs) but neither can be handed
  // our private, signed Storage URL directly — Gemini in particular only
  // accepts inline bytes or a Google-hosted file URI. So for any image
  // attachment on a vision-capable model, download the bytes from Storage
  // here and re-encode as a data URL before building the provider payload.
  const imageDataUrlCache = new Map<string, string>();
  async function toImageDataUrl(attachment: Attachment): Promise<string | null> {
    if (!attachment.storage_path) return attachment.url ?? null;
    const cached = imageDataUrlCache.get(attachment.storage_path);
    if (cached) return cached;
    const { data, error } = await supabase.storage.from('attachments').download(attachment.storage_path);
    if (error || !data) return null;
    const buffer = Buffer.from(await data.arrayBuffer());
    const dataUrl = `data:${attachment.type};base64,${buffer.toString('base64')}`;
    imageDataUrlCache.set(attachment.storage_path, dataUrl);
    return dataUrl;
  }

  const providerMessages: ProviderMessage[] = [{ role: 'system', content: SYSTEM_PROMPT }];

  for (const m of history) {
    const attachments = (m.attachments as Attachment[]) ?? [];
    let images: string[] | undefined;

    if (model.supportsImages) {
      const imageAttachments = attachments.filter((a) => a.type.startsWith('image/'));
      const resolved = await Promise.all(imageAttachments.map(toImageDataUrl));
      images = resolved.filter((u): u is string => !!u);
    }

    const attachmentNote = attachments.length
      ? `\n\n[Attached files: ${attachments.map((a) => a.name).join(', ')}]`
      : '';

    providerMessages.push({
      role: m.role as 'user' | 'assistant' | 'system',
      content: `${m.content}${attachmentNote}`,
      images: images?.length ? images : undefined
    });
  }

  const provider = getProviderFor(model);
  const encoder = new TextEncoder();
  const signal = request.signal;

  const stream = new ReadableStream({
    async start(controller) {
      let full = '';
      let streamError: string | undefined;
      let closed = false;

      const safeEnqueue = (chunk: string) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(chunk));
        } catch {
          closed = true;
        }
      };

      try {
        for await (const chunk of provider.streamChat(providerMessages, model.apiModel)) {
          if (signal.aborted) break;
          if (chunk.error) {
            streamError = chunk.error;
            safeEnqueue(`event: error\ndata: ${JSON.stringify({ error: chunk.error })}\n\n`);
            break;
          }
          if (chunk.delta) {
            full += chunk.delta;
            safeEnqueue(`event: delta\ndata: ${JSON.stringify({ delta: chunk.delta })}\n\n`);
          }
          if (chunk.done) break;
        }
      } catch (e) {
        streamError = e instanceof Error ? e.message : 'Unexpected error while generating a response.';
        safeEnqueue(`event: error\ndata: ${JSON.stringify({ error: streamError })}\n\n`);
      }

      // Persist whatever was generated — even a partial response from a
      // user-initiated stop, or an error — so the transcript stays truthful.
      let saved = null;
      if (full || streamError) {
        const { data } = await supabase
          .from('messages')
          .insert({
            conversation_id: conversationId,
            user_id: user.id,
            role: 'assistant',
            content: full,
            attachments: [],
            model: model.id,
            error: full ? null : streamError ?? null
          })
          .select('*')
          .single();
        saved = data;
      }

      safeEnqueue(`event: done\ndata: ${JSON.stringify({ message: saved })}\n\n`);
      if (!closed) {
        try {
          controller.close();
        } catch {
          // Already closed by the client aborting — nothing to do.
        }
      }
    }
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive'
    }
  });
}
