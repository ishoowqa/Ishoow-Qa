import { NextResponse } from 'next/server';
import { createClient, createServiceClient } from '@/lib/supabase/server';

// DELETE /api/account — permanently deletes the signed-in user's account.
// Conversations, messages, settings, and attachment rows all cascade via
// the foreign keys defined in supabase/schema.sql.
export async function DELETE() {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });

  if (!process.env.SUPABASE_SERVICE_ROLE_KEY) {
    return NextResponse.json(
      { error: 'Account deletion requires SUPABASE_SERVICE_ROLE_KEY to be set on the server.' },
      { status: 501 }
    );
  }

  const admin = createServiceClient();
  const { error } = await admin.auth.admin.deleteUser(user.id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  await supabase.auth.signOut();
  return NextResponse.json({ success: true });
}
