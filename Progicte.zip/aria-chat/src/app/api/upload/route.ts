import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { ACCEPTED_FILE_TYPES, MAX_FILE_SIZE_BYTES, MAX_FILE_SIZE_MB } from '@/lib/utils';

// POST /api/upload — multipart form upload (file + conversationId).
// Stores the file in the private "attachments" Storage bucket under
// {userId}/{conversationId}/{uuid}-{filename}, records metadata in the
// attachments table, and returns a signed URL the client can preview/send.
export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });

  const form = await request.formData().catch(() => null);
  const file = form?.get('file');
  const conversationId = form?.get('conversationId');

  if (!file || !(file instanceof File) || typeof conversationId !== 'string') {
    return NextResponse.json({ error: 'file and conversationId are required' }, { status: 400 });
  }

  if (file.size > MAX_FILE_SIZE_BYTES) {
    return NextResponse.json({ error: `Files must be smaller than ${MAX_FILE_SIZE_MB}MB.` }, { status: 413 });
  }

  if (!ACCEPTED_FILE_TYPES.includes(file.type)) {
    return NextResponse.json({ error: 'That file type isn\u2019t supported.' }, { status: 415 });
  }

  const safeName = file.name.replace(/[^\w.\-]+/g, '_');
  const storagePath = `${user.id}/${conversationId}/${crypto.randomUUID()}-${safeName}`;

  const arrayBuffer = await file.arrayBuffer();
  const { error: uploadError } = await supabase.storage
    .from('attachments')
    .upload(storagePath, arrayBuffer, { contentType: file.type, upsert: false });

  if (uploadError) {
    return NextResponse.json({ error: `Upload failed: ${uploadError.message}` }, { status: 500 });
  }

  const { data: signed, error: signError } = await supabase.storage
    .from('attachments')
    .createSignedUrl(storagePath, 60 * 60 * 24 * 7);

  if (signError) {
    return NextResponse.json({ error: `Could not create a file URL: ${signError.message}` }, { status: 500 });
  }

  const { data: attachmentRow } = await supabase
    .from('attachments')
    .insert({
      user_id: user.id,
      file_name: file.name,
      file_type: file.type,
      file_size: file.size,
      storage_path: storagePath
    })
    .select('id')
    .single();

  return NextResponse.json({
    attachment: {
      id: attachmentRow?.id ?? crypto.randomUUID(),
      name: file.name,
      type: file.type,
      size: file.size,
      url: signed.signedUrl,
      storage_path: storagePath,
      status: 'done'
    }
  });
}
