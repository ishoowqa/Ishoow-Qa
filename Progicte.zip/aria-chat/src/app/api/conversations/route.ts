import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { DEFAULT_MODEL } from '@/lib/ai/registry';

// GET /api/conversations?query=search+term
// Lists the signed-in user's conversations, optionally filtered by title or
// message content, newest-updated first.
export async function GET(request: Request) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const query = searchParams.get('query')?.trim();

  if (query) {
    // Search by title first, then fall back to a message-content match so
    // "search by conversation title or message content" both work.
    const [byTitle, byMessage] = await Promise.all([
      supabase
        .from('conversations')
        .select('*')
        .eq('user_id', user.id)
        .ilike('title', `%${query}%`)
        .order('updated_at', { ascending: false }),
      supabase
        .from('messages')
        .select('conversation_id, conversations!inner(*)')
        .eq('user_id', user.id)
        .ilike('content', `%${query}%`)
        .limit(50)
    ]);

    if (byTitle.error) return NextResponse.json({ error: byTitle.error.message }, { status: 500 });
    if (byMessage.error) return NextResponse.json({ error: byMessage.error.message }, { status: 500 });

    const seen = new Map<string, any>();
    for (const c of byTitle.data ?? []) seen.set(c.id, c);
    for (const row of (byMessage.data ?? []) as any[]) {
      const convo = row.conversations;
      if (convo && !seen.has(convo.id)) seen.set(convo.id, convo);
    }

    const results = Array.from(seen.values()).sort(
      (a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
    );
    return NextResponse.json({ conversations: results });
  }

  const { data, error } = await supabase
    .from('conversations')
    .select('*')
    .eq('user_id', user.id)
    .order('pinned', { ascending: false })
    .order('updated_at', { ascending: false });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ conversations: data });
}

// POST /api/conversations — creates a new empty conversation.
export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });

  const body = await request.json().catch(() => ({}));
  const model = body?.model ?? DEFAULT_MODEL;

  const { data, error } = await supabase
    .from('conversations')
    .insert({ user_id: user.id, title: 'New chat', model })
    .select('*')
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ conversation: data });
}
