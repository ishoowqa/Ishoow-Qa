import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { ChatView } from '@/components/chat/chat-view';
import { getModelOptions } from '@/lib/ai/model-options';
import type { ChatMessage, Conversation } from '@/types/database';

export default async function ConversationPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();

  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) notFound();

  const { data: conversation } = await supabase
    .from('conversations')
    .select('*')
    .eq('id', id)
    .eq('user_id', user.id)
    .single();

  if (!conversation) notFound();

  const { data: messages } = await supabase
    .from('messages')
    .select('*')
    .eq('conversation_id', id)
    .order('created_at', { ascending: true });

  return (
    <ChatView
      conversation={conversation as Conversation}
      initialMessages={(messages ?? []) as ChatMessage[]}
      models={getModelOptions()}
    />
  );
}
