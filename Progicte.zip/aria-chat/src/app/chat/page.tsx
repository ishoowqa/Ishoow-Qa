import { NewChatView } from '@/components/chat/new-chat-view';
import { getModelOptions } from '@/lib/ai/model-options';

export default function ChatIndexPage() {
  return <NewChatView models={getModelOptions()} />;
}
