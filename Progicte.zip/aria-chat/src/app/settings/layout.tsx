import Link from 'next/link';

export default function SettingsLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-dvh flex-col bg-canvas">
      <header className="flex h-14 shrink-0 items-center gap-3 border-b border-border px-4">
        <Link
          href="/chat"
          aria-label="Back to chat"
          className="flex h-8 w-8 items-center justify-center rounded-lg text-ink hover:bg-surface-raised"
        >
          <svg width="18" height="18" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12.5 4.5L6 10l6.5 5.5" />
          </svg>
        </Link>
        <h1 className="text-sm font-semibold text-ink">Settings</h1>
      </header>
      <div className="flex-1 overflow-y-auto">{children}</div>
    </div>
  );
}
