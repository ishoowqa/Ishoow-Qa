'use client';

import type { User } from '@supabase/supabase-js';
import { AuthProvider } from '@/contexts/auth-context';
import { ThemeProvider } from '@/contexts/theme-context';
import { I18nProvider } from '@/contexts/i18n-context';
import { ToastProvider } from '@/contexts/toast-context';
import { SidebarProvider } from '@/contexts/sidebar-context';
import { Toaster } from '@/components/ui/toaster';
import type { Language, Theme } from '@/types/database';

export function Providers({
  children,
  initialUser,
  initialTheme,
  initialLanguage
}: {
  children: React.ReactNode;
  initialUser: User | null;
  initialTheme: Theme;
  initialLanguage: Language;
}) {
  return (
    <AuthProvider initialUser={initialUser}>
      <ThemeProvider initialTheme={initialTheme}>
        <I18nProvider initialLanguage={initialLanguage}>
          <ToastProvider>
            <SidebarProvider>
              {children}
              <Toaster />
            </SidebarProvider>
          </ToastProvider>
        </I18nProvider>
      </ThemeProvider>
    </AuthProvider>
  );
}
