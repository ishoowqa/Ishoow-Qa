'use client';

import { useCallback, useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import type { Conversation, ModelId } from '@/types/database';
import { useToast } from '@/contexts/toast-context';
import { useI18n } from '@/contexts/i18n-context';

export function useConversations() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const { showToast } = useToast();
  const { t } = useI18n();

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/conversations');
      if (!res.ok) throw new Error();
      const data = await res.json();
      setConversations(data.conversations ?? []);
    } catch {
      showToast(t('errorNetwork'), 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast, t]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const createConversation = useCallback(
    async (model?: ModelId) => {
      try {
        const res = await fetch('/api/conversations', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ model })
        });
        if (!res.ok) throw new Error();
        const data = await res.json();
        setConversations((prev) => [data.conversation, ...prev]);
        return data.conversation as Conversation;
      } catch {
        showToast(t('errorGeneric'), 'error');
        return null;
      }
    },
    [showToast, t]
  );

  const renameConversation = useCallback(
    async (id: string, title: string) => {
      setConversations((prev) => prev.map((c) => (c.id === id ? { ...c, title } : c)));
      try {
        const res = await fetch(`/api/conversations/${id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ title })
        });
        if (!res.ok) throw new Error();
        showToast(t('conversationRenamed'), 'success');
      } catch {
        showToast(t('errorGeneric'), 'error');
        refresh();
      }
    },
    [refresh, showToast, t]
  );

  const togglePin = useCallback(
    async (id: string, pinned: boolean) => {
      setConversations((prev) => prev.map((c) => (c.id === id ? { ...c, pinned } : c)));
      try {
        const res = await fetch(`/api/conversations/${id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pinned })
        });
        if (!res.ok) throw new Error();
        showToast(pinned ? t('conversationPinned') : t('conversationUnpinned'), 'success');
      } catch {
        showToast(t('errorGeneric'), 'error');
        refresh();
      }
    },
    [refresh, showToast, t]
  );

  const deleteConversation = useCallback(
    async (id: string, currentId?: string) => {
      const prev = conversations;
      setConversations((c) => c.filter((conv) => conv.id !== id));
      try {
        const res = await fetch(`/api/conversations/${id}`, { method: 'DELETE' });
        if (!res.ok) throw new Error();
        showToast(t('conversationDeleted'), 'success');
        if (currentId === id) router.push('/chat');
      } catch {
        setConversations(prev);
        showToast(t('errorGeneric'), 'error');
      }
    },
    [conversations, router, showToast, t]
  );

  return { conversations, loading, refresh, createConversation, renameConversation, togglePin, deleteConversation, setConversations };
}
