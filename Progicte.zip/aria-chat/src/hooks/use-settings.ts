'use client';

import { useCallback, useEffect, useState } from 'react';
import type { UserSettings } from '@/types/database';
import { useTheme } from '@/contexts/theme-context';
import { useI18n } from '@/contexts/i18n-context';
import { useToast } from '@/contexts/toast-context';

export function useSettings() {
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const { setTheme } = useTheme();
  const { setLanguage, t } = useI18n();
  const { showToast } = useToast();

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch('/api/settings');
        if (!res.ok) throw new Error();
        const data = await res.json();
        setSettings(data.settings);
      } catch {
        // Non-fatal — the app still works with client-side defaults.
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const update = useCallback(
    async (patch: Partial<UserSettings>) => {
      setSettings((prev) => (prev ? { ...prev, ...patch } : prev));
      if (patch.theme) setTheme(patch.theme);
      if (patch.language) setLanguage(patch.language);
      try {
        const res = await fetch('/api/settings', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(patch)
        });
        if (!res.ok) throw new Error();
      } catch {
        showToast(t('errorGeneric'), 'error');
      }
    },
    [setTheme, setLanguage, showToast, t]
  );

  return { settings, loading, update };
}
