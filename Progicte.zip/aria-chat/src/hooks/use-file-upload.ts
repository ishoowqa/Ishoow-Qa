'use client';

import { useCallback, useState } from 'react';
import type { Attachment } from '@/types/database';
import { ACCEPTED_FILE_TYPES, MAX_FILE_SIZE_BYTES, MAX_FILE_SIZE_MB, generateId, isImageType } from '@/lib/utils';
import { useToast } from '@/contexts/toast-context';
import { useI18n } from '@/contexts/i18n-context';

/** Uploads via XMLHttpRequest (not fetch) so we get real progress events. */
function uploadWithProgress(
  file: File,
  conversationId: string,
  onProgress: (pct: number) => void
): Promise<Attachment> {
  return new Promise((resolve, reject) => {
    const form = new FormData();
    form.append('file', file);
    form.append('conversationId', conversationId);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/upload');
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100));
    };
    xhr.onload = () => {
      try {
        const data = JSON.parse(xhr.responseText);
        if (xhr.status >= 200 && xhr.status < 300) resolve(data.attachment);
        else reject(new Error(data.error || 'Upload failed'));
      } catch {
        reject(new Error('Upload failed'));
      }
    };
    xhr.onerror = () => reject(new Error('Network error during upload'));
    xhr.send(form);
  });
}

export function useFileUpload(conversationId: string) {
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const { showToast } = useToast();
  const { t } = useI18n();

  const addFiles = useCallback(
    async (files: FileList | File[]) => {
      for (const file of Array.from(files)) {
        if (file.size > MAX_FILE_SIZE_BYTES) {
          showToast(t('errorFileTooLarge')(MAX_FILE_SIZE_MB), 'error');
          continue;
        }
        if (!ACCEPTED_FILE_TYPES.includes(file.type)) {
          showToast(t('errorFileType'), 'error');
          continue;
        }

        const localId = generateId();
        let previewDataUrl: string | undefined;
        if (isImageType(file.type)) {
          previewDataUrl = await new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.readAsDataURL(file);
          });
        }

        setAttachments((prev) => [
          ...prev,
          {
            id: localId,
            name: file.name,
            type: file.type,
            size: file.size,
            status: 'uploading',
            progress: 0,
            previewDataUrl
          }
        ]);

        try {
          const uploaded = await uploadWithProgress(file, conversationId, (pct) => {
            setAttachments((prev) => prev.map((a) => (a.id === localId ? { ...a, progress: pct } : a)));
          });
          setAttachments((prev) =>
            prev.map((a) => (a.id === localId ? { ...uploaded, previewDataUrl: a.previewDataUrl } : a))
          );
        } catch (err) {
          const message = err instanceof Error ? err.message : t('errorGeneric');
          setAttachments((prev) =>
            prev.map((a) => (a.id === localId ? { ...a, status: 'error', errorMessage: message } : a))
          );
          showToast(message, 'error');
        }
      }
    },
    [conversationId, showToast, t]
  );

  const removeAttachment = useCallback((id: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  }, []);

  const clearAttachments = useCallback(() => setAttachments([]), []);

  return { attachments, addFiles, removeAttachment, clearAttachments };
}
