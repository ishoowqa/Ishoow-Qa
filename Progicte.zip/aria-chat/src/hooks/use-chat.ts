'use client';

import { useCallback, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import type { Attachment, ChatMessage, ModelId } from '@/types/database';
import { generateId, toPersistableAttachment } from '@/lib/utils';
import { useToast } from '@/contexts/toast-context';
import { useI18n } from '@/contexts/i18n-context';

interface UseChatOptions {
  conversationId: string;
  initialMessages: ChatMessage[];
  onFirstMessage?: (title: string) => void;
}

/** Parses a text/event-stream body into { event, data } pairs. */
async function* parseSSE(reader: ReadableStreamDefaultReader<Uint8Array>) {
  const decoder = new TextDecoder();
  let buffer = '';
  while (true) {
    const { value, done } = await reader.read();
    if (done) return;
    buffer += decoder.decode(value, { stream: true });
    const chunks = buffer.split('\n\n');
    buffer = chunks.pop() ?? '';
    for (const chunk of chunks) {
      const lines = chunk.split('\n');
      let event = 'message';
      let data = '';
      for (const line of lines) {
        if (line.startsWith('event:')) event = line.slice(6).trim();
        if (line.startsWith('data:')) data = line.slice(5).trim();
      }
      if (data) yield { event, data: JSON.parse(data) };
    }
  }
}

export function useChat({ conversationId, initialMessages }: UseChatOptions) {
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [isGenerating, setIsGenerating] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const { showToast } = useToast();
  const { t } = useI18n();
  const router = useRouter();

  const runStream = useCallback(
    async (modelId: ModelId) => {
      setIsGenerating(true);
      const controller = new AbortController();
      abortRef.current = controller;

      const placeholderId = generateId();
      setMessages((prev) => [
        ...prev,
        {
          id: placeholderId,
          conversation_id: conversationId,
          user_id: '',
          role: 'assistant',
          content: '',
          attachments: [],
          model: modelId,
          created_at: new Date().toISOString(),
          streaming: true
        }
      ]);

      try {
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ conversationId, modelId }),
          signal: controller.signal
        });

        if (!res.ok || !res.body) {
          const payload = await res.json().catch(() => ({}));
          throw new Error(payload.error || t('errorGeneric'));
        }

        const reader = res.body.getReader();
        for await (const { event, data } of parseSSE(reader)) {
          if (event === 'delta') {
            setMessages((prev) =>
              prev.map((m) => (m.id === placeholderId ? { ...m, content: m.content + data.delta } : m))
            );
          } else if (event === 'error') {
            setMessages((prev) =>
              prev.map((m) => (m.id === placeholderId ? { ...m, error: data.error, streaming: false } : m))
            );
            showToast(data.error, 'error');
          } else if (event === 'done') {
            setMessages((prev) =>
              prev.map((m) =>
                m.id === placeholderId
                  ? data.message
                    ? { ...data.message, streaming: false }
                    : { ...m, streaming: false }
                  : m
              )
            );
          }
        }
      } catch (err) {
        if ((err as Error).name === 'AbortError') {
          setMessages((prev) => prev.map((m) => (m.id === placeholderId ? { ...m, streaming: false } : m)));
        } else {
          const msg = err instanceof Error ? err.message : t('errorGeneric');
          setMessages((prev) =>
            prev.map((m) => (m.id === placeholderId ? { ...m, error: msg, streaming: false } : m))
          );
          showToast(msg, 'error');
        }
      } finally {
        setIsGenerating(false);
        abortRef.current = null;
        router.refresh();
      }
    },
    [conversationId, router, showToast, t]
  );

  const sendMessage = useCallback(
    async (content: string, attachments: Attachment[], modelId: ModelId) => {
      if (!content.trim() && attachments.length === 0) {
        showToast(t('errorEmptyMessage'), 'error');
        return;
      }

      const optimistic: ChatMessage = {
        id: generateId(),
        conversation_id: conversationId,
        user_id: '',
        role: 'user',
        content,
        attachments,
        created_at: new Date().toISOString()
      };
      setMessages((prev) => [...prev, optimistic]);

      try {
        const res = await fetch('/api/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            conversationId,
            role: 'user',
            content,
            attachments: attachments.map(toPersistableAttachment)
          })
        });
        if (!res.ok) throw new Error(t('errorGeneric'));
        const data = await res.json();
        setMessages((prev) => prev.map((m) => (m.id === optimistic.id ? data.message : m)));
      } catch {
        showToast(t('errorGeneric'), 'error');
        setMessages((prev) => prev.filter((m) => m.id !== optimistic.id));
        return;
      }

      await runStream(modelId);
    },
    [conversationId, runStream, showToast, t]
  );

  const stopGenerating = useCallback(() => {
    abortRef.current?.abort();
  }, []);

  const regenerate = useCallback(
    async (assistantMessageId: string, modelId: ModelId) => {
      const idx = messages.findIndex((m) => m.id === assistantMessageId);
      if (idx === -1) return;
      const target = messages[idx];

      try {
        await fetch(
          `/api/messages?conversationId=${conversationId}&afterCreatedAt=${encodeURIComponent(target.created_at)}`,
          { method: 'DELETE' }
        );
      } catch {
        showToast(t('errorGeneric'), 'error');
        return;
      }

      setMessages((prev) => prev.slice(0, idx));
      await runStream(modelId);
    },
    [conversationId, messages, runStream, showToast, t]
  );

  const editMessage = useCallback(
    async (userMessageId: string, newContent: string, modelId: ModelId) => {
      const idx = messages.findIndex((m) => m.id === userMessageId);
      if (idx === -1) return;
      const target = messages[idx];

      try {
        await fetch(`/api/messages/${userMessageId}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ content: newContent })
        });
        await fetch(
          `/api/messages?conversationId=${conversationId}&afterCreatedAt=${encodeURIComponent(
            new Date(new Date(target.created_at).getTime() + 1).toISOString()
          )}`,
          { method: 'DELETE' }
        );
      } catch {
        showToast(t('errorGeneric'), 'error');
        return;
      }

      setMessages((prev) => {
        const next = prev.slice(0, idx + 1);
        next[idx] = { ...next[idx], content: newContent };
        return next;
      });
      await runStream(modelId);
    },
    [conversationId, messages, runStream, showToast, t]
  );

  const deleteMessage = useCallback(
    async (messageId: string) => {
      const prev = messages;
      setMessages((m) => m.filter((msg) => msg.id !== messageId));
      try {
        const res = await fetch(`/api/messages?id=${messageId}`, { method: 'DELETE' });
        if (!res.ok) throw new Error();
      } catch {
        setMessages(prev);
        showToast(t('errorGeneric'), 'error');
      }
    },
    [messages, showToast, t]
  );

  const toggleLike = useCallback(async (messageId: string, liked: boolean | null) => {
    setMessages((prev) => prev.map((m) => (m.id === messageId ? { ...m, liked } : m)));
    try {
      await fetch(`/api/messages/${messageId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ liked })
      });
    } catch {
      // Non-critical — leave the optimistic UI state as-is.
    }
  }, []);

  return {
    messages,
    isGenerating,
    sendMessage,
    stopGenerating,
    regenerate,
    editMessage,
    deleteMessage,
    toggleLike
  };
}
