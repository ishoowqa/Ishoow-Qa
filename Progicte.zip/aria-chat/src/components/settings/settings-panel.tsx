'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useSettings } from '@/hooks/use-settings';
import { useI18n } from '@/contexts/i18n-context';
import { useTheme } from '@/contexts/theme-context';
import { useAuth } from '@/contexts/auth-context';
import { useToast } from '@/contexts/toast-context';
import { createClient } from '@/lib/supabase/client';
import { SettingsSection, SettingsRow } from './settings-section';
import { Switch } from '@/components/ui/switch';
import { Input, Label } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Dialog } from '@/components/ui/dialog';
import { SunIcon, MoonIcon, LaptopIcon } from '@/components/ui/icons';
import { cn } from '@/lib/utils';
import type { Language, Theme } from '@/types/database';

export function SettingsPanel() {
  const { settings, loading, update } = useSettings();
  const { t, language } = useI18n();
  const { theme } = useTheme();
  const { user, signOut } = useAuth();
  const { showToast } = useToast();
  const router = useRouter();

  const [displayName, setDisplayName] = useState('');
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);

  const effectiveName = displayName || settings?.display_name || '';

  const handleDeleteAccount = async () => {
    setDeleteLoading(true);
    try {
      const res = await fetch('/api/account', { method: 'DELETE' });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || t('errorGeneric'));
      await createClient().auth.signOut();
      router.push('/login');
    } catch (err) {
      showToast(err instanceof Error ? err.message : t('errorGeneric'), 'error');
    } finally {
      setDeleteLoading(false);
      setConfirmingDelete(false);
    }
  };

  if (loading) {
    return <p className="p-6 text-sm text-muted">{t('loading')}</p>;
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6 p-4 sm:p-6">
      <SettingsSection title={t('appearance')}>
        <SettingsRow
          label={t('appearance')}
          control={
            <div className="flex gap-1 rounded-lg border border-border p-0.5">
              {(
                [
                  { value: 'light', icon: SunIcon, label: t('light') },
                  { value: 'dark', icon: MoonIcon, label: t('dark') },
                  { value: 'system', icon: LaptopIcon, label: t('system') }
                ] as { value: Theme; icon: typeof SunIcon; label: string }[]
              ).map(({ value, icon: Icon, label }) => (
                <button
                  key={value}
                  onClick={() => update({ theme: value })}
                  aria-pressed={theme === value}
                  title={label}
                  className={cn(
                    'flex h-8 w-8 items-center justify-center rounded-md',
                    theme === value ? 'bg-accent text-accent-ink' : 'text-muted hover:bg-surface-raised'
                  )}
                >
                  <Icon className="h-4 w-4" />
                </button>
              ))}
            </div>
          }
        />
      </SettingsSection>

      <SettingsSection title={t('language')}>
        <SettingsRow
          label={t('language')}
          control={
            <div className="flex gap-1 rounded-lg border border-border p-0.5">
              {(
                [
                  { value: 'en', label: t('english') },
                  { value: 'ar', label: t('arabic') }
                ] as { value: Language; label: string }[]
              ).map(({ value, label }) => (
                <button
                  key={value}
                  onClick={() => update({ language: value })}
                  aria-pressed={language === value}
                  className={cn(
                    'rounded-md px-3 py-1.5 text-sm font-medium',
                    language === value ? 'bg-accent text-accent-ink' : 'text-muted hover:bg-surface-raised'
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
          }
        />
      </SettingsSection>

      <SettingsSection title={t('chatSettings')}>
        <SettingsRow
          label={t('enterToSend')}
          description={t('enterToSendDesc')}
          control={
            <Switch
              checked={settings?.enter_to_send ?? true}
              onChange={(checked) => update({ enter_to_send: checked })}
              label={t('enterToSend')}
            />
          }
        />
        <SettingsRow
          label={t('showTimestamps')}
          description={t('showTimestampsDesc')}
          control={
            <Switch
              checked={settings?.show_timestamps ?? true}
              onChange={(checked) => update({ show_timestamps: checked })}
              label={t('showTimestamps')}
            />
          }
        />
        <SettingsRow
          label={t('saveHistory')}
          description={t('saveHistoryDesc')}
          control={
            <Switch
              checked={settings?.save_chat_history ?? true}
              onChange={(checked) => update({ save_chat_history: checked })}
              label={t('saveHistory')}
            />
          }
        />
      </SettingsSection>

      <SettingsSection title={t('account')}>
        <div className="rounded-xl border border-border bg-surface p-4">
          <Label htmlFor="displayName">{t('displayName')}</Label>
          <div className="flex gap-2">
            <Input
              id="displayName"
              value={effectiveName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder={user?.email ?? ''}
            />
            <Button
              variant="secondary"
              onClick={() => {
                update({ display_name: effectiveName });
                showToast(t('saved'), 'success');
              }}
            >
              {t('save')}
            </Button>
          </div>
          <p className="mt-2 text-xs text-muted">{user?.email}</p>
        </div>

        <SettingsRow label={t('logout')} control={<Button variant="secondary" onClick={() => signOut()}>{t('logout')}</Button>} />

        <SettingsRow
          label={t('deleteAccount')}
          description={t('deleteAccountBody')}
          control={
            <Button variant="danger" onClick={() => setConfirmingDelete(true)}>
              {t('deleteAccount')}
            </Button>
          }
        />
      </SettingsSection>

      <Dialog
        open={confirmingDelete}
        onClose={() => setConfirmingDelete(false)}
        title={t('deleteAccount')}
        description={t('deleteAccountBody')}
      >
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setConfirmingDelete(false)}>
            {t('cancel')}
          </Button>
          <Button variant="danger" onClick={handleDeleteAccount} loading={deleteLoading}>
            {t('confirm')}
          </Button>
        </div>
      </Dialog>
    </div>
  );
}
