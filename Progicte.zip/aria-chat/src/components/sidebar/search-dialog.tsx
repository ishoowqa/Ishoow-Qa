'use client';

import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import type { Conversation } from '@/types/database';
import { useI18n } from '@/contexts/i18n-context';
import { Dialog } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { SearchIcon } from '@/components/ui/icons';

export function SearchDialog({ open, onClose, onNavigate }: { open: boolean; onClose: () => void; onNavigate?: () => void }) {
  const { t } = useI18n();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!open) {
      setQuery('');
      setResults([]);
    }
  }, [open]);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!query.trim()) {
      setResults([]);
      return;
    }
    debounceRef.current = setTimeout(async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/conversations?query=${encodeURIComponent(query.trim())}`);
        const data = await res.json();
        setResults(data.conversations ?? []);
      } finally {
        setLoading(false);
      }
    }, 250);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [query]);

  return (
    <Dialog open={open} onClose={onClose} title={t('searchChats')} className="max-w-lg">
      <div className="relative">
        <SearchIcon className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
        <Input
          autoFocus
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t('searchPlaceholder')}
          className="ps-9"
        />
      </div>
      <div className="mt-3 max-h-72 space-y-0.5 overflow-y-auto">
        {loading && <p className="px-2 py-3 text-sm text-muted">{t('loading')}</p>}
        {!loading && query.trim() && results.length === 0 && (
          <p className="px-2 py-3 text-sm text-muted">{t('noResults')}</p>
        )}
        {results.map((c) => (
          <Link
            key={c.id}
            href={`/chat/${c.id}`}
            onClick={() => {
              onClose();
              onNavigate?.();
            }}
            className="block truncate rounded-lg px-2.5 py-2 text-sm text-ink hover:bg-surface-raised"
          >
            {c.title}
          </Link>
        ))}
      </div>
    </Dialog>
  );
}
