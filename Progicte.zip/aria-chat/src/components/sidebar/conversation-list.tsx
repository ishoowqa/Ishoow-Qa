'use client';

import { useMemo } from 'react';
import type { Conversation } from '@/types/database';
import { dateBucket } from '@/lib/utils';
import { useI18n } from '@/contexts/i18n-context';
import { ConversationListSkeleton } from '@/components/ui/skeleton';
import { ConversationItem } from './conversation-item';

const SECTION_ORDER = ['today', 'yesterday', 'previous7', 'older'] as const;

export function ConversationList({
  conversations,
  loading,
  activeId,
  onRename,
  onTogglePin,
  onDelete,
  onNavigate
}: {
  conversations: Conversation[];
  loading: boolean;
  activeId?: string;
  onRename: (id: string, title: string) => void;
  onTogglePin: (id: string, pinned: boolean) => void;
  onDelete: (id: string) => void;
  onNavigate?: () => void;
}) {
  const { t } = useI18n();

  const { pinned, sections } = useMemo(() => {
    const pinned = conversations.filter((c) => c.pinned);
    const rest = conversations.filter((c) => !c.pinned);
    const grouped: Record<string, Conversation[]> = { today: [], yesterday: [], previous7: [], older: [] };
    for (const c of rest) grouped[dateBucket(c.updated_at)].push(c);
    return { pinned, sections: grouped };
  }, [conversations]);

  if (loading) return <ConversationListSkeleton />;

  if (conversations.length === 0) {
    return <p className="px-3 py-6 text-center text-sm text-muted">{t('noResults')}</p>;
  }

  const sectionLabels: Record<(typeof SECTION_ORDER)[number], string> = {
    today: t('today'),
    yesterday: t('yesterday'),
    previous7: t('previous7'),
    older: t('older')
  };

  return (
    <nav className="space-y-4 px-2 pb-4" aria-label={t('searchChats')}>
      {pinned.length > 0 && (
        <div>
          <h3 className="px-2 pb-1 text-xs font-medium text-muted">{t('pinned')}</h3>
          <div className="space-y-0.5">
            {pinned.map((c) => (
              <ConversationItem
                key={c.id}
                conversation={c}
                active={c.id === activeId}
                onRename={onRename}
                onTogglePin={onTogglePin}
                onDelete={onDelete}
                onNavigate={onNavigate}
              />
            ))}
          </div>
        </div>
      )}
      {SECTION_ORDER.map((key) =>
        sections[key].length > 0 ? (
          <div key={key}>
            <h3 className="px-2 pb-1 text-xs font-medium text-muted">{sectionLabels[key]}</h3>
            <div className="space-y-0.5">
              {sections[key].map((c) => (
                <ConversationItem
                  key={c.id}
                  conversation={c}
                  active={c.id === activeId}
                  onRename={onRename}
                  onTogglePin={onTogglePin}
                  onDelete={onDelete}
                  onNavigate={onNavigate}
                />
              ))}
            </div>
          </div>
        ) : null
      )}
    </nav>
  );
}
