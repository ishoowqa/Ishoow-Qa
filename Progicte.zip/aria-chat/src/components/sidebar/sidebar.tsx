'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import { useConversations } from '@/hooks/use-conversations';
import { useI18n } from '@/contexts/i18n-context';
import { useSidebar } from '@/contexts/sidebar-context';
import { Button } from '@/components/ui/button';
import { Tooltip } from '@/components/ui/tooltip';
import { ConversationList } from './conversation-list';
import { SearchDialog } from './search-dialog';
import { UserMenu } from './user-menu';
import { PlusIcon, SearchIcon, SidebarIcon, SparkleIcon, XIcon } from '@/components/ui/icons';
import { cn } from '@/lib/utils';

export function Sidebar() {
  const { t } = useI18n();
  const router = useRouter();
  const params = useParams();
  const activeId = typeof params?.id === 'string' ? params.id : undefined;
  const { conversations, loading, renameConversation, togglePin, deleteConversation, createConversation } =
    useConversations();
  const { collapsed, toggleCollapsed, mobileOpen, setMobileOpen, isMobile } = useSidebar();
  const [searchOpen, setSearchOpen] = useState(false);

  const handleNewChat = async () => {
    const convo = await createConversation();
    if (convo) {
      router.push(`/chat/${convo.id}`);
      setMobileOpen(false);
    }
  };

  const isOpen = isMobile ? mobileOpen : true;
  const isCollapsed = !isMobile && collapsed;

  const content = (
    <div className="flex h-full flex-col">
      <div className={cn('flex items-center gap-2 px-3 pt-3', isCollapsed && 'flex-col')}>
        <Link href="/chat" className="flex flex-1 items-center gap-2 rounded-lg px-1 py-1.5 text-ink">
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-accent text-accent-ink">
            <SparkleIcon className="h-4 w-4" />
          </span>
          {!isCollapsed && <span className="text-base font-semibold">{t('appName')}</span>}
        </Link>
        {isMobile ? (
          <button
            aria-label="Close menu"
            onClick={() => setMobileOpen(false)}
            className="rounded-lg p-1.5 text-muted hover:bg-surface-raised hover:text-ink"
          >
            <XIcon className="h-5 w-5" />
          </button>
        ) : (
          <Tooltip label={t('settings')}>
            <button
              aria-label="Collapse sidebar"
              onClick={toggleCollapsed}
              className="rounded-lg p-1.5 text-muted hover:bg-surface-raised hover:text-ink"
            >
              <SidebarIcon className="h-[18px] w-[18px]" />
            </button>
          </Tooltip>
        )}
      </div>

      <div className={cn('flex flex-col gap-1 px-2 pt-3', isCollapsed && 'items-center')}>
        <Button
          variant="secondary"
          onClick={handleNewChat}
          className={cn('justify-start gap-2', isCollapsed && 'w-9 justify-center px-0')}
          title={t('newChat')}
        >
          <PlusIcon className="h-4 w-4 shrink-0" />
          {!isCollapsed && t('newChat')}
        </Button>
        <Button
          variant="ghost"
          onClick={() => setSearchOpen(true)}
          className={cn('justify-start gap-2', isCollapsed && 'w-9 justify-center px-0')}
          title={t('searchChats')}
        >
          <SearchIcon className="h-4 w-4 shrink-0" />
          {!isCollapsed && t('searchChats')}
        </Button>
      </div>

      {!isCollapsed && (
        <div className="mt-3 flex-1 overflow-y-auto">
          <ConversationList
            conversations={conversations}
            loading={loading}
            activeId={activeId}
            onRename={renameConversation}
            onTogglePin={togglePin}
            onDelete={(id) => deleteConversation(id, activeId)}
            onNavigate={() => setMobileOpen(false)}
          />
        </div>
      )}
      {isCollapsed && <div className="flex-1" />}

      <div className="border-t border-border p-2">{!isCollapsed && <UserMenu />}</div>

      <SearchDialog open={searchOpen} onClose={() => setSearchOpen(false)} onNavigate={() => setMobileOpen(false)} />
    </div>
  );

  if (isMobile) {
    return (
      <>
        {isOpen && (
          <div className="fixed inset-0 z-40 bg-black/40 animate-fade-in md:hidden" onClick={() => setMobileOpen(false)} />
        )}
        <aside
          className={cn(
            'fixed inset-y-0 start-0 z-50 w-72 max-w-[85vw] border-e border-border bg-canvas transition-transform duration-200 md:hidden',
            isOpen ? 'translate-x-0' : 'rtl:translate-x-full ltr:-translate-x-full'
          )}
        >
          {content}
        </aside>
      </>
    );
  }

  return (
    <aside
      className={cn(
        'hidden shrink-0 border-e border-border bg-canvas transition-[width] duration-200 md:flex',
        isCollapsed ? 'w-16' : 'w-72'
      )}
    >
      {content}
    </aside>
  );
}
