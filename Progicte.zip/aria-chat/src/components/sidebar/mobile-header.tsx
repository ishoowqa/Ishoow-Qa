'use client';

import { useRouter } from 'next/navigation';
import { useI18n } from '@/contexts/i18n-context';
import { useSidebar } from '@/contexts/sidebar-context';
import { useConversations } from '@/hooks/use-conversations';
import { MenuIcon, PlusIcon, SparkleIcon } from '@/components/ui/icons';

export function MobileHeader({ title }: { title?: string }) {
  const { t } = useI18n();
  const { setMobileOpen } = useSidebar();
  const { createConversation } = useConversations();
  const router = useRouter();

  return (
    <header className="flex h-14 shrink-0 items-center justify-between border-b border-border bg-canvas px-2 md:hidden">
      <button
        aria-label="Open menu"
        onClick={() => setMobileOpen(true)}
        className="rounded-lg p-2 text-ink hover:bg-surface-raised"
      >
        <MenuIcon className="h-5 w-5" />
      </button>
      <div className="flex min-w-0 flex-1 items-center justify-center gap-1.5 px-2">
        {!title && <SparkleIcon className="h-4 w-4 text-accent" />}
        <span className="truncate text-sm font-medium text-ink">{title || t('appName')}</span>
      </div>
      <button
        aria-label={t('newChat')}
        onClick={async () => {
          const convo = await createConversation();
          if (convo) router.push(`/chat/${convo.id}`);
        }}
        className="rounded-lg p-2 text-ink hover:bg-surface-raised"
      >
        <PlusIcon className="h-5 w-5" />
      </button>
    </header>
  );
}
