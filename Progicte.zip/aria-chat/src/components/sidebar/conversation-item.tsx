'use client';

import { useState } from 'react';
import Link from 'next/link';
import type { Conversation } from '@/types/database';
import { cn } from '@/lib/utils';
import { useI18n } from '@/contexts/i18n-context';
import { Dropdown, DropdownTrigger, DropdownMenu, DropdownItem } from '@/components/ui/dropdown';
import { Dialog } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { DotsIcon, EditIcon, PinIcon, TrashIcon } from '@/components/ui/icons';

export function ConversationItem({
  conversation,
  active,
  onRename,
  onTogglePin,
  onDelete,
  onNavigate
}: {
  conversation: Conversation;
  active: boolean;
  onRename: (id: string, title: string) => void;
  onTogglePin: (id: string, pinned: boolean) => void;
  onDelete: (id: string) => void;
  onNavigate?: () => void;
}) {
  const { t } = useI18n();
  const [renaming, setRenaming] = useState(false);
  const [draftTitle, setDraftTitle] = useState(conversation.title);
  const [confirmingDelete, setConfirmingDelete] = useState(false);

  const submitRename = () => {
    const title = draftTitle.trim();
    setRenaming(false);
    if (title && title !== conversation.title) onRename(conversation.id, title);
    else setDraftTitle(conversation.title);
  };

  if (renaming) {
    return (
      <div className="px-1 py-0.5">
        <Input
          autoFocus
          value={draftTitle}
          onChange={(e) => setDraftTitle(e.target.value)}
          onBlur={submitRename}
          onKeyDown={(e) => {
            if (e.key === 'Enter') submitRename();
            if (e.key === 'Escape') {
              setDraftTitle(conversation.title);
              setRenaming(false);
            }
          }}
          className="h-8 text-sm"
        />
      </div>
    );
  }

  return (
    <div
      className={cn(
        'group relative flex items-center rounded-lg text-sm',
        active ? 'bg-surface-raised text-ink' : 'text-ink/85 hover:bg-surface-raised'
      )}
    >
      <Link
        href={`/chat/${conversation.id}`}
        onClick={onNavigate}
        className="flex-1 truncate py-2 ps-3 pe-1"
        title={conversation.title}
      >
        {conversation.pinned && <PinIcon className="me-1.5 inline h-3 w-3 -translate-y-px text-accent" />}
        {conversation.title}
      </Link>

      <Dropdown>
        <DropdownTrigger>
          <button
            aria-label="Conversation options"
            className={cn(
              'me-1 rounded-md p-1.5 text-muted opacity-0 hover:bg-surface hover:text-ink group-hover:opacity-100',
              'focus-visible:opacity-100'
            )}
          >
            <DotsIcon className="h-4 w-4" />
          </button>
        </DropdownTrigger>
        <DropdownMenu align="end">
          <DropdownItem onSelect={() => setRenaming(true)}>
            <EditIcon className="h-4 w-4" /> {t('rename')}
          </DropdownItem>
          <DropdownItem onSelect={() => onTogglePin(conversation.id, !conversation.pinned)}>
            <PinIcon className="h-4 w-4" /> {conversation.pinned ? t('unpin') : t('pin')}
          </DropdownItem>
          <DropdownItem danger onSelect={() => setConfirmingDelete(true)}>
            <TrashIcon className="h-4 w-4" /> {t('delete')}
          </DropdownItem>
        </DropdownMenu>
      </Dropdown>

      <Dialog open={confirmingDelete} onClose={() => setConfirmingDelete(false)} title={t('deleteChat')} description={t('deleteChatBody')}>
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setConfirmingDelete(false)}>
            {t('cancel')}
          </Button>
          <Button
            variant="danger"
            onClick={() => {
              setConfirmingDelete(false);
              onDelete(conversation.id);
            }}
          >
            {t('delete')}
          </Button>
        </div>
      </Dialog>
    </div>
  );
}
