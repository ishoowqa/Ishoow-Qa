'use client';

import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/auth-context';
import { useI18n } from '@/contexts/i18n-context';
import { Dropdown, DropdownTrigger, DropdownMenu, DropdownItem } from '@/components/ui/dropdown';
import { LogOutIcon, SettingsIcon } from '@/components/ui/icons';

export function UserMenu() {
  const { user, signOut } = useAuth();
  const { t } = useI18n();
  const router = useRouter();

  const label = (user?.user_metadata?.full_name as string) || user?.email || '';
  const initial = label.trim().charAt(0).toUpperCase() || '?';

  return (
    <Dropdown>
      <DropdownTrigger>
        <button className="flex w-full items-center gap-2.5 rounded-lg px-2 py-2 text-start hover:bg-surface-raised">
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-accent text-xs font-semibold text-accent-ink">
            {initial}
          </span>
          <span className="min-w-0 flex-1 truncate text-sm text-ink">{label}</span>
        </button>
      </DropdownTrigger>
      <DropdownMenu align="start" side="top" className="mb-1">
        <DropdownItem onSelect={() => router.push('/settings')}>
          <SettingsIcon className="h-4 w-4" /> {t('settings')}
        </DropdownItem>
        <DropdownItem danger onSelect={() => signOut()}>
          <LogOutIcon className="h-4 w-4" /> {t('logout')}
        </DropdownItem>
      </DropdownMenu>
    </Dropdown>
  );
}
