'use client';

import { useState } from 'react';
import Image from 'next/image';
import type { ChatMessage, ModelId } from '@/types/database';
import { formatTimestamp, isImageType } from '@/lib/utils';
import { useI18n } from '@/contexts/i18n-context';
import { MessageContent } from './message-content';
import { AssistantMessageActions, UserMessageActions } from './message-actions';
import { Button } from '@/components/ui/button';
import { FileIcon, SparkleIcon, AlertIcon } from '@/components/ui/icons';
import { cn } from '@/lib/utils';

export function MessageBubble({
  message,
  showTimestamps,
  onRegenerate,
  onToggleLike,
  onEdit,
  onDelete
}: {
  message: ChatMessage;
  showTimestamps: boolean;
  onRegenerate: (modelId: ModelId) => void;
  onToggleLike: (liked: boolean | null) => void;
  onEdit: (newContent: string) => void;
  onDelete: () => void;
}) {
  const { t, language } = useI18n();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(message.content);
  const isUser = message.role === 'user';

  if (editing) {
    return (
      <div className="mx-auto w-full max-w-3xl px-4 py-2">
        <div className="ms-auto max-w-[85%] rounded-2xl border border-accent/40 bg-surface p-3">
          <textarea
            autoFocus
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            rows={Math.min(8, Math.max(2, draft.split('\n').length))}
            className="w-full resize-none bg-transparent text-sm text-ink outline-none"
          />
          <div className="mt-2 flex justify-end gap-2">
            <Button
              size="sm"
              variant="secondary"
              onClick={() => {
                setDraft(message.content);
                setEditing(false);
              }}
            >
              {t('cancel')}
            </Button>
            <Button
              size="sm"
              variant="primary"
              onClick={() => {
                setEditing(false);
                onEdit(draft.trim());
              }}
              disabled={!draft.trim()}
            >
              {t('save')}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={cn('mx-auto w-full max-w-3xl px-4 py-2 animate-fade-in')}>
      <div className={cn('flex gap-3', isUser && 'flex-row-reverse')}>
        {!isUser && (
          <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-accent text-accent-ink">
            <SparkleIcon className="h-3.5 w-3.5" />
          </span>
        )}
        <div className={cn('min-w-0 flex-1', isUser && 'flex flex-col items-end')}>
          {message.attachments.length > 0 && (
            <div className={cn('mb-1.5 flex flex-wrap gap-2', isUser && 'justify-end')}>
              {message.attachments.map((a) => (
                <div key={a.id} className="overflow-hidden rounded-lg border border-border">
                  {isImageType(a.type) && (a.previewDataUrl || a.url) ? (
                    <Image
                      src={a.previewDataUrl || a.url!}
                      alt={a.name}
                      width={160}
                      height={160}
                      unoptimized
                      className="h-28 w-28 object-cover"
                    />
                  ) : (
                    <div className="flex h-10 items-center gap-2 bg-surface px-3">
                      <FileIcon className="h-4 w-4 text-muted" />
                      <span className="max-w-[9rem] truncate text-xs text-ink">{a.name}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {message.content && (
            <div className={cn(isUser && 'rounded-2xl bg-surface-raised px-4 py-2.5')}>
              <MessageContent content={message.content} streaming={message.streaming} />
            </div>
          )}

          {message.error && (
            <div className="mt-1.5 flex items-start gap-2 rounded-xl border border-danger/30 bg-danger/5 px-3 py-2 text-sm text-danger">
              <AlertIcon className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{message.error}</span>
            </div>
          )}

          {showTimestamps && (
            <p className={cn('mt-1 text-xs text-muted', isUser && 'text-end')}>
              {formatTimestamp(message.created_at, language === 'ar' ? 'ar' : 'en-US')}
            </p>
          )}

          {!message.streaming &&
            (isUser ? (
              <UserMessageActions content={message.content} onEdit={() => setEditing(true)} onDelete={onDelete} />
            ) : message.content ? (
              <AssistantMessageActions
                content={message.content}
                liked={message.liked}
                onRegenerate={() => onRegenerate((message.model as ModelId) || 'balanced')}
                onToggleLike={onToggleLike}
                onShare={() => {}}
                onReport={() => {}}
              />
            ) : null)}
        </div>
      </div>
    </div>
  );
}
