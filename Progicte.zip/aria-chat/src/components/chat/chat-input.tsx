'use client';

import { useEffect, useRef, useState } from 'react';
import type { Attachment, ModelId } from '@/types/database';
import { useI18n } from '@/contexts/i18n-context';
import { useToast } from '@/contexts/toast-context';
import { useSpeechRecognition } from '@/hooks/use-speech-recognition';
import { useFileUpload } from '@/hooks/use-file-upload';
import { ACCEPTED_FILE_TYPES } from '@/lib/utils';
import { Tooltip } from '@/components/ui/tooltip';
import { AttachmentChip } from './attachment-chip';
import { ModelSelector, type ModelOption } from './model-selector';
import { MicIcon, PaperclipIcon, SendIcon, StopIcon } from '@/components/ui/icons';
import { cn } from '@/lib/utils';

export function ChatInput({
  conversationId,
  models,
  model,
  onModelChange,
  enterToSend,
  isGenerating,
  onSend,
  onStop,
  initialText
}: {
  conversationId: string;
  models: ModelOption[];
  model: ModelId;
  onModelChange: (id: ModelId) => void;
  enterToSend: boolean;
  isGenerating: boolean;
  onSend: (content: string, attachments: Attachment[]) => void;
  onStop: () => void;
  initialText?: string;
}) {
  const { t } = useI18n();
  const { showToast } = useToast();
  const [text, setText] = useState(initialText ?? '');
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { attachments, addFiles, removeAttachment, clearAttachments } = useFileUpload(conversationId);

  const currentModel = models.find((m) => m.id === model);

  const { supported: voiceSupported, listening, start, stop } = useSpeechRecognition((transcript, isFinal) => {
    setText((prev) => {
      const base = prev.replace(/\u2026$/, '');
      return isFinal ? `${base}${base && !base.endsWith(' ') ? ' ' : ''}${transcript} ` : `${base}${transcript}\u2026`;
    });
  });

  useEffect(() => {
    if (initialText !== undefined) setText(initialText);
  }, [initialText]);

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
  }, [text]);

  const hasUploading = attachments.some((a) => a.status === 'uploading');
  const canSend = (text.trim().length > 0 || attachments.length > 0) && !hasUploading && !isGenerating;

  const handleSend = () => {
    if (!canSend) return;
    onSend(text.trim(), attachments.filter((a) => a.status !== 'error'));
    setText('');
    clearAttachments();
    if (listening) stop();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key !== 'Enter' || e.shiftKey || e.nativeEvent.isComposing) return;
    if (enterToSend) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleAttachClick = () => {
    fileInputRef.current?.click();
  };

  const handleFiles = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const hasImage = Array.from(files).some((f) => f.type.startsWith('image/'));
    if (hasImage && currentModel && !currentModel.supportsImages) {
      showToast(t('imageUnsupported'), 'error');
    }
    addFiles(files);
  };

  const handleVoiceClick = () => {
    if (!voiceSupported) {
      showToast(t('voiceUnsupported'), 'error');
      return;
    }
    listening ? stop() : start();
  };

  return (
    <div className="border-t border-border bg-canvas px-3 pb-[calc(env(safe-area-inset-bottom)+0.75rem)] pt-3 sm:px-4">
      <div className="mx-auto max-w-3xl">
        {attachments.length > 0 && (
          <div className="mb-2 flex flex-wrap gap-2">
            {attachments.map((a) => (
              <AttachmentChip key={a.id} attachment={a} onRemove={() => removeAttachment(a.id)} />
            ))}
          </div>
        )}

        <div className="flex items-end gap-2 rounded-2xl border border-border bg-surface p-2 shadow-sm focus-within:border-accent/50">
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept={ACCEPTED_FILE_TYPES.join(',')}
            className="hidden"
            onChange={(e) => {
              handleFiles(e.target.files);
              e.target.value = '';
            }}
          />
          <Tooltip label={t('attach')}>
            <button
              onClick={handleAttachClick}
              aria-label={t('attach')}
              className="shrink-0 rounded-xl p-2 text-muted hover:bg-surface-raised hover:text-ink"
            >
              <PaperclipIcon className="h-5 w-5" />
            </button>
          </Tooltip>

          <textarea
            ref={textareaRef}
            rows={1}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={listening ? t('listening') : t('messagePlaceholder')}
            className="max-h-[200px] flex-1 resize-none bg-transparent py-2 text-sm text-ink outline-none placeholder:text-muted"
          />

          <Tooltip label={listening ? t('voiceStop') : t('voiceStart')}>
            <button
              onClick={handleVoiceClick}
              aria-label={listening ? t('voiceStop') : t('voiceStart')}
              aria-pressed={listening}
              className={cn(
                'shrink-0 rounded-xl p-2 hover:bg-surface-raised',
                listening ? 'text-danger' : 'text-muted hover:text-ink'
              )}
            >
              <MicIcon className={cn('h-5 w-5', listening && 'animate-pulse')} />
            </button>
          </Tooltip>

          {isGenerating ? (
            <button
              onClick={onStop}
              aria-label={t('stopGenerating')}
              className="shrink-0 rounded-xl bg-ink p-2 text-canvas hover:brightness-110"
            >
              <StopIcon className="h-5 w-5" />
            </button>
          ) : (
            <button
              onClick={handleSend}
              disabled={!canSend}
              aria-label={t('send')}
              className="shrink-0 rounded-xl bg-accent p-2 text-accent-ink transition-opacity disabled:opacity-40"
            >
              <SendIcon className="h-5 w-5" />
            </button>
          )}
        </div>

        <div className="mt-2 flex items-center justify-between">
          <ModelSelector models={models} value={model} onChange={onModelChange} />
          <p className="hidden text-xs text-muted sm:block">
            {enterToSend ? 'Enter ↵' : `Shift + Enter ↵`}
          </p>
        </div>
      </div>
    </div>
  );
}
