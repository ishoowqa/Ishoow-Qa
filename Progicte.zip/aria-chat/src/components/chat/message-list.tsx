'use client';

import { useEffect, useRef } from 'react';
import type { ChatMessage, ModelId } from '@/types/database';
import { MessageBubble } from './message-bubble';

export function MessageList({
  messages,
  showTimestamps,
  onRegenerate,
  onToggleLike,
  onEdit,
  onDelete
}: {
  messages: ChatMessage[];
  showTimestamps: boolean;
  onRegenerate: (messageId: string, modelId: ModelId) => void;
  onToggleLike: (messageId: string, liked: boolean | null) => void;
  onEdit: (messageId: string, newContent: string) => void;
  onDelete: (messageId: string) => void;
}) {
  const bottomRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const wasNearBottom = useRef(true);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const onScroll = () => {
      wasNearBottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 120;
    };
    el.addEventListener('scroll', onScroll);
    return () => el.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (wasNearBottom.current) bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages]);

  return (
    <div ref={containerRef} className="flex-1 overflow-y-auto">
      <div className="py-4">
        {messages.map((message) => (
          <MessageBubble
            key={message.id}
            message={message}
            showTimestamps={showTimestamps}
            onRegenerate={(modelId) => onRegenerate(message.id, modelId)}
            onToggleLike={(liked) => onToggleLike(message.id, liked)}
            onEdit={(content) => onEdit(message.id, content)}
            onDelete={() => onDelete(message.id)}
          />
        ))}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}
