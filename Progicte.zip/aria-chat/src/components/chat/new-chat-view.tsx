'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import type { Attachment, ModelId } from '@/types/database';
import type { ModelOption } from './model-selector';
import { useSettings } from '@/hooks/use-settings';
import { useToast } from '@/contexts/toast-context';
import { useI18n } from '@/contexts/i18n-context';
import { MobileHeader } from '@/components/sidebar/mobile-header';
import { EmptyState } from './empty-state';
import { ChatInput } from './chat-input';

/**
 * Landing view for /chat — no conversation exists yet. On first send, it
 * creates the conversation, stashes the pending message so the freshly
 * mounted ChatView can send it, and navigates there.
 */
export function NewChatView({ models }: { models: ModelOption[] }) {
  const router = useRouter();
  const { settings } = useSettings();
  const { showToast } = useToast();
  const { t } = useI18n();
  const [model, setModel] = useState<ModelId>((settings?.default_model as ModelId) || 'balanced');
  const [pending, setPending] = useState(false);
  const [draft, setDraft] = useState<string | undefined>(undefined);

  const handleSend = async (content: string, attachments: Attachment[]) => {
    if (pending) return;
    setPending(true);
    try {
      const res = await fetch('/api/conversations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model })
      });
      if (!res.ok) throw new Error();
      const { conversation } = await res.json();

      window.sessionStorage.setItem(
        `aria-pending-${conversation.id}`,
        JSON.stringify({ content, attachments, model })
      );
      router.push(`/chat/${conversation.id}`);
    } catch {
      showToast(t('errorGeneric'), 'error');
      setPending(false);
    }
  };

  return (
    <div className="flex h-dvh flex-1 flex-col">
      <MobileHeader />
      <EmptyState onPick={(prompt) => setDraft(prompt)} />
      <ChatInput
        conversationId="pending"
        models={models}
        model={model}
        onModelChange={setModel}
        enterToSend={settings?.enter_to_send ?? true}
        isGenerating={pending}
        onSend={handleSend}
        onStop={() => {}}
        initialText={draft}
      />
    </div>
  );
}
