'use client';

import { useEffect, useState } from 'react';
import type { Attachment, ChatMessage, Conversation, ModelId } from '@/types/database';
import type { ModelOption } from './model-selector';
import { useChat } from '@/hooks/use-chat';
import { useSettings } from '@/hooks/use-settings';
import { useI18n } from '@/contexts/i18n-context';
import { MobileHeader } from '@/components/sidebar/mobile-header';
import { MessageList } from './message-list';
import { ChatInput } from './chat-input';
import { EmptyState } from './empty-state';

export function ChatView({
  conversation,
  initialMessages,
  models
}: {
  conversation: Conversation;
  initialMessages: ChatMessage[];
  models: ModelOption[];
}) {
  const { messages, isGenerating, sendMessage, stopGenerating, regenerate, editMessage, deleteMessage, toggleLike } =
    useChat({ conversationId: conversation.id, initialMessages });
  const { settings, update } = useSettings();
  const { t } = useI18n();
  const [model, setModel] = useState<ModelId>(conversation.model);
  const [draftFromEmptyState, setDraftFromEmptyState] = useState<string | undefined>(undefined);

  const showTimestamps = settings?.show_timestamps ?? true;
  const enterToSend = settings?.enter_to_send ?? true;

  // If we arrived here via NewChatView, a pending first message is waiting
  // in sessionStorage — send it now that this conversation's ChatView (and
  // its streaming machinery) is actually mounted.
  useEffect(() => {
    const key = `aria-pending-${conversation.id}`;
    const raw = window.sessionStorage.getItem(key);
    if (!raw) return;
    window.sessionStorage.removeItem(key);
    try {
      const pending = JSON.parse(raw) as { content: string; attachments: Attachment[]; model: ModelId };
      setModel(pending.model);
      sendMessage(pending.content, pending.attachments, pending.model);
    } catch {
      // Malformed payload — ignore, the user can just type their message.
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [conversation.id]);

  // Respect the "save chat history" setting: if the user has it off, this
  // conversation is purged the moment they navigate away from it, so it
  // never persists past the current viewing session.
  useEffect(() => {
    return () => {
      if (settings && settings.save_chat_history === false) {
        fetch(`/api/conversations/${conversation.id}`, { method: 'DELETE' }).catch(() => {});
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [conversation.id, settings?.save_chat_history]);

  const handleSend = (content: string, attachments: Attachment[]) => {
    sendMessage(content, attachments, model);
  };

  return (
    <div className="flex h-dvh flex-1 flex-col">
      <MobileHeader title={conversation.title !== 'New chat' ? conversation.title : undefined} />
      {messages.length === 0 ? (
        <EmptyState onPick={(prompt) => setDraftFromEmptyState(prompt)} />
      ) : (
        <MessageList
          messages={messages}
          showTimestamps={showTimestamps}
          onRegenerate={(id, modelId) => regenerate(id, modelId)}
          onToggleLike={toggleLike}
          onEdit={(id, content) => editMessage(id, content, model)}
          onDelete={deleteMessage}
        />
      )}
      <ChatInput
        conversationId={conversation.id}
        models={models}
        model={model}
        onModelChange={(id) => {
          setModel(id);
          update({ default_model: id });
        }}
        enterToSend={enterToSend}
        isGenerating={isGenerating}
        onSend={handleSend}
        onStop={stopGenerating}
        initialText={draftFromEmptyState}
      />
    </div>
  );
}
