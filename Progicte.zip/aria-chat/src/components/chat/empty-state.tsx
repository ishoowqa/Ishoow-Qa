'use client';

import { useI18n } from '@/contexts/i18n-context';
import { SparkleIcon } from '@/components/ui/icons';

const PROMPT_KEYS = [
  'Explain quantum computing in simple terms',
  'Write a professional email declining a meeting',
  'Suggest names for a productivity app',
  'Summarize the plot of a book in three sentences'
];

export function EmptyState({ onPick }: { onPick: (prompt: string) => void }) {
  const { t } = useI18n();

  return (
    <div className="mx-auto flex h-full max-w-2xl flex-col items-center justify-center px-4 text-center">
      <span className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-accent text-accent-ink">
        <SparkleIcon className="h-6 w-6" />
      </span>
      <h1 className="text-2xl font-semibold text-ink">{t('emptyStateTitle')}</h1>
      <p className="mt-2 text-sm text-muted">{t('emptyStateSubtitle')}</p>
      <div className="mt-6 grid w-full grid-cols-1 gap-2 sm:grid-cols-2">
        {PROMPT_KEYS.map((prompt) => (
          <button
            key={prompt}
            onClick={() => onPick(prompt)}
            className="rounded-xl border border-border bg-surface p-3 text-start text-sm text-ink transition-colors hover:bg-surface-raised"
          >
            {prompt}
          </button>
        ))}
      </div>
    </div>
  );
}
