'use client';

import { useState } from 'react';
import { useI18n } from '@/contexts/i18n-context';
import { useToast } from '@/contexts/toast-context';
import { Tooltip } from '@/components/ui/tooltip';
import {
  CopyIcon,
  CheckIcon,
  RefreshIcon,
  ThumbsUpIcon,
  ThumbsDownIcon,
  ShareIcon,
  FlagIcon,
  EditIcon,
  TrashIcon
} from '@/components/ui/icons';
import { cn } from '@/lib/utils';

function ActionButton({
  label,
  onClick,
  active,
  activeClassName,
  children
}: {
  label: string;
  onClick: () => void;
  active?: boolean;
  activeClassName?: string;
  children: React.ReactNode;
}) {
  return (
    <Tooltip label={label}>
      <button
        onClick={onClick}
        aria-label={label}
        aria-pressed={active}
        className={cn(
          'rounded-md p-1.5 text-muted transition-colors hover:bg-surface-raised hover:text-ink',
          active && (activeClassName || 'text-accent')
        )}
      >
        {children}
      </button>
    </Tooltip>
  );
}

export function AssistantMessageActions({
  content,
  liked,
  onRegenerate,
  onToggleLike,
  onShare,
  onReport
}: {
  content: string;
  liked?: boolean | null;
  onRegenerate: () => void;
  onToggleLike: (liked: boolean | null) => void;
  onShare: () => void;
  onReport: () => void;
}) {
  const { t } = useI18n();
  const { showToast } = useToast();
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    await navigator.clipboard.writeText(content);
    setCopied(true);
    showToast(t('copied'), 'success');
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="mt-1.5 flex items-center gap-0.5">
      <ActionButton label={copied ? t('copied') : t('copy')} onClick={copy}>
        {copied ? <CheckIcon className="h-4 w-4" /> : <CopyIcon className="h-4 w-4" />}
      </ActionButton>
      <ActionButton label={t('regenerate')} onClick={onRegenerate}>
        <RefreshIcon className="h-4 w-4" />
      </ActionButton>
      <ActionButton label={t('like')} onClick={() => onToggleLike(liked === true ? null : true)} active={liked === true}>
        <ThumbsUpIcon className="h-4 w-4" />
      </ActionButton>
      <ActionButton
        label={t('dislike')}
        onClick={() => onToggleLike(liked === false ? null : false)}
        active={liked === false}
        activeClassName="text-danger"
      >
        <ThumbsDownIcon className="h-4 w-4" />
      </ActionButton>
      <ActionButton
        label={t('share')}
        onClick={async () => {
          await navigator.clipboard.writeText(content);
          showToast(t('linkCopied'), 'success');
          onShare();
        }}
      >
        <ShareIcon className="h-4 w-4" />
      </ActionButton>
      <ActionButton
        label={t('report')}
        onClick={() => {
          showToast(t('reported'), 'success');
          onReport();
        }}
      >
        <FlagIcon className="h-4 w-4" />
      </ActionButton>
    </div>
  );
}

export function UserMessageActions({
  content,
  onEdit,
  onDelete
}: {
  content: string;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const { t } = useI18n();
  const { showToast } = useToast();

  const copy = async () => {
    await navigator.clipboard.writeText(content);
    showToast(t('copied'), 'success');
  };

  return (
    <div className="mt-1.5 flex items-center justify-end gap-0.5">
      <ActionButton label={t('copy')} onClick={copy}>
        <CopyIcon className="h-4 w-4" />
      </ActionButton>
      <ActionButton label={t('edit')} onClick={onEdit}>
        <EditIcon className="h-4 w-4" />
      </ActionButton>
      <ActionButton label={t('delete')} onClick={onDelete}>
        <TrashIcon className="h-4 w-4" />
      </ActionButton>
    </div>
  );
}
