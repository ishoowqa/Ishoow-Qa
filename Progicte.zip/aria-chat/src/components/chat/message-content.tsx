'use client';

import { useEffect, useMemo, useRef } from 'react';
import { renderMarkdown } from '@/lib/markdown';
import { useI18n } from '@/contexts/i18n-context';
import { useToast } from '@/contexts/toast-context';

/**
 * Renders assistant/user message markdown and wires up the copy-code
 * buttons that `renderMarkdown` embeds into each fenced code block.
 */
export function MessageContent({ content, streaming }: { content: string; streaming?: boolean }) {
  const html = useMemo(() => renderMarkdown(content), [content]);
  const ref = useRef<HTMLDivElement>(null);
  const { t } = useI18n();
  const { showToast } = useToast();

  useEffect(() => {
    const root = ref.current;
    if (!root) return;

    const onClick = async (e: Event) => {
      const target = (e.target as HTMLElement).closest('[data-copy-code]') as HTMLElement | null;
      if (!target) return;
      const block = target.closest('.code-block') as HTMLElement | null;
      const raw = block?.dataset.code ? decodeURIComponent(block.dataset.code) : '';
      try {
        await navigator.clipboard.writeText(raw);
        const original = target.textContent;
        target.textContent = t('copied');
        showToast(t('copied'), 'success');
        window.setTimeout(() => {
          if (target) target.textContent = original;
        }, 1500);
      } catch {
        showToast(t('errorGeneric'), 'error');
      }
    };

    root.addEventListener('click', onClick);
    return () => root.removeEventListener('click', onClick);
  }, [t, showToast]);

  return (
    <div
      ref={ref}
      className={`prose-chat ${streaming ? 'streaming-cursor' : ''}`}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}
