'use client';

import Image from 'next/image';
import type { Attachment } from '@/types/database';
import { formatFileSize, isImageType } from '@/lib/utils';
import { useI18n } from '@/contexts/i18n-context';
import { FileIcon, XIcon, AlertIcon } from '@/components/ui/icons';
import { cn } from '@/lib/utils';

export function AttachmentChip({ attachment, onRemove }: { attachment: Attachment; onRemove?: () => void }) {
  const { t } = useI18n();
  const preview = attachment.previewDataUrl || (isImageType(attachment.type) ? attachment.url : undefined);

  return (
    <div className="relative flex items-center gap-2 rounded-xl border border-border bg-surface p-1.5 pe-3">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-surface-raised">
        {preview ? (
          <Image src={preview} alt={attachment.name} width={40} height={40} className="h-full w-full object-cover" unoptimized />
        ) : (
          <FileIcon className="h-5 w-5 text-muted" />
        )}
      </div>
      <div className="min-w-0">
        <p className="max-w-[9rem] truncate text-xs font-medium text-ink">{attachment.name}</p>
        {attachment.status === 'uploading' ? (
          <div className="mt-1 h-1 w-24 overflow-hidden rounded-full bg-surface-raised">
            <div
              className="h-full rounded-full bg-accent transition-all"
              style={{ width: `${attachment.progress ?? 0}%` }}
            />
          </div>
        ) : attachment.status === 'error' ? (
          <p className="flex items-center gap-1 text-xs text-danger">
            <AlertIcon className="h-3 w-3" /> {attachment.errorMessage}
          </p>
        ) : (
          <p className="text-xs text-muted">{formatFileSize(attachment.size)}</p>
        )}
      </div>
      {onRemove && (
        <button
          onClick={onRemove}
          aria-label={t('removeAttachment')}
          className={cn(
            'absolute -end-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full border border-border bg-surface text-muted hover:text-ink'
          )}
        >
          <XIcon className="h-3 w-3" />
        </button>
      )}
    </div>
  );
}
