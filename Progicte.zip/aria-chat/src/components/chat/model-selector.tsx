'use client';

import type { ModelId } from '@/types/database';
import { useI18n } from '@/contexts/i18n-context';
import { Dropdown, DropdownTrigger, DropdownMenu } from '@/components/ui/dropdown';
import { ChevronDownIcon, CheckIcon, AlertIcon } from '@/components/ui/icons';
import { cn } from '@/lib/utils';

export interface ModelOption {
  id: ModelId;
  label: string;
  description: string;
  available: boolean;
  missingEnvVar?: string;
  supportsImages: boolean;
}

export function ModelSelector({
  models,
  value,
  onChange
}: {
  models: ModelOption[];
  value: ModelId;
  onChange: (id: ModelId) => void;
}) {
  const { t } = useI18n();
  const current = models.find((m) => m.id === value) ?? models[0];

  return (
    <Dropdown>
      <DropdownTrigger>
        <button className="flex items-center gap-1.5 rounded-lg border border-border bg-surface px-2.5 py-1.5 text-sm font-medium text-ink hover:bg-surface-raised">
          {current?.label ?? value}
          <ChevronDownIcon className="h-3.5 w-3.5 text-muted" />
        </button>
      </DropdownTrigger>
      <DropdownMenu align="start" className="w-72 p-1.5">
        {models.map((model) => (
          <button
            key={model.id}
            role="menuitem"
            disabled={!model.available}
            onClick={() => model.available && onChange(model.id)}
            className={cn(
              'flex w-full items-start gap-2 rounded-lg px-2.5 py-2 text-start transition-colors',
              model.available ? 'hover:bg-surface-raised' : 'cursor-not-allowed opacity-50'
            )}
          >
            <span className="mt-0.5 h-4 w-4 shrink-0">
              {model.id === value && model.available && <CheckIcon className="h-4 w-4 text-accent" />}
              {!model.available && <AlertIcon className="h-4 w-4 text-muted" />}
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-sm font-medium text-ink">{model.label}</span>
              <span className="block text-xs text-muted">
                {model.available ? model.description : model.missingEnvVar ? t('modelUnavailableBody')(model.missingEnvVar) : t('modelUnavailable')}
              </span>
            </span>
          </button>
        ))}
      </DropdownMenu>
    </Dropdown>
  );
}
