'use client';

import { createContext, useContext, useEffect, useRef, useState } from 'react';
import { cn } from '@/lib/utils';

interface DropdownContextValue {
  open: boolean;
  setOpen: (open: boolean) => void;
}

const DropdownContext = createContext<DropdownContextValue | null>(null);

export function Dropdown({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', onClick);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onClick);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  return (
    <DropdownContext.Provider value={{ open, setOpen }}>
      <div ref={ref} className="relative inline-block">
        {children}
      </div>
    </DropdownContext.Provider>
  );
}

export function DropdownTrigger({ children }: { children: React.ReactNode }) {
  const ctx = useContext(DropdownContext)!;
  return (
    <div onClick={() => ctx.setOpen(!ctx.open)} className="cursor-pointer">
      {children}
    </div>
  );
}

export function DropdownMenu({
  children,
  align = 'start',
  side = 'bottom',
  className
}: {
  children: React.ReactNode;
  align?: 'start' | 'end';
  side?: 'top' | 'bottom';
  className?: string;
}) {
  const ctx = useContext(DropdownContext)!;
  if (!ctx.open) return null;
  return (
    <div
      role="menu"
      className={cn(
        'absolute z-40 min-w-[10rem] rounded-xl border border-border bg-surface p-1 shadow-lg animate-fade-in',
        side === 'top' ? 'bottom-full mb-1.5' : 'top-full mt-1.5',
        align === 'end' ? 'end-0' : 'start-0',
        className
      )}
    >
      {children}
    </div>
  );
}

export function DropdownItem({
  children,
  onSelect,
  danger,
  className
}: {
  children: React.ReactNode;
  onSelect?: () => void;
  danger?: boolean;
  className?: string;
}) {
  const ctx = useContext(DropdownContext)!;
  return (
    <button
      role="menuitem"
      onClick={() => {
        onSelect?.();
        ctx.setOpen(false);
      }}
      className={cn(
        'flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-start text-sm transition-colors',
        danger ? 'text-danger hover:bg-danger/10' : 'text-ink hover:bg-surface-raised',
        className
      )}
    >
      {children}
    </button>
  );
}

export function useDropdownClose() {
  const ctx = useContext(DropdownContext)!;
  return () => ctx.setOpen(false);
}
