import type { SVGProps } from 'react';

/**
 * Small hand-rolled icon set (stroke-based, 1.5px, 20x20 viewbox) so the
 * app has zero icon-library dependency. Each icon is a plain function
 * component accepting standard SVG props.
 */
type IconProps = SVGProps<SVGSVGElement>;

const base = {
  width: 20,
  height: 20,
  viewBox: '0 0 20 20',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.6,
  strokeLinecap: 'round' as const,
  strokeLinejoin: 'round' as const
};

export const PlusIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M10 4v12M4 10h12" />
  </svg>
);

export const SearchIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <circle cx="8.5" cy="8.5" r="5.5" />
    <path d="M16 16l-3.2-3.2" />
  </svg>
);

export const MenuIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M3 5h14M3 10h14M3 15h14" />
  </svg>
);

export const SidebarIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <rect x="3" y="3.5" width="14" height="13" rx="2.2" />
    <path d="M8 3.5v13" />
  </svg>
);

export const SendIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M17 3L3 9.5l5.8 2.3M17 3l-5.4 14-2.8-6.2M17 3L8.8 11.8" />
  </svg>
);

export const StopIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <rect x="5" y="5" width="10" height="10" rx="2" />
  </svg>
);

export const CopyIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <rect x="7.5" y="7.5" width="9" height="9" rx="1.8" />
    <path d="M12.5 7.5V5.3A1.8 1.8 0 0 0 10.7 3.5H5.3A1.8 1.8 0 0 0 3.5 5.3v5.4a1.8 1.8 0 0 0 1.8 1.8H7.5" />
  </svg>
);

export const CheckIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M4 10.5l4 4 8-9" />
  </svg>
);

export const RefreshIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M16 8a6 6 0 10-1.3 6.6M16 8V4M16 8h-4" />
  </svg>
);

export const ThumbsUpIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M7 18V9l4-6 1 1-1 5h5.3a1.7 1.7 0 011.65 2.05l-1.3 6A1.7 1.7 0 0115 18H7z" />
    <path d="M7 9H4v9h3" />
  </svg>
);

export const ThumbsDownIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M13 2v9l-4 6-1-1 1-5H3.7A1.7 1.7 0 012.05 8.95l1.3-6A1.7 1.7 0 015 2h8z" />
    <path d="M13 11h3V2h-3" />
  </svg>
);

export const ShareIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <circle cx="15" cy="5" r="2.2" />
    <circle cx="15" cy="15" r="2.2" />
    <circle cx="5" cy="10" r="2.2" />
    <path d="M7 9l6-3M7 11l6 3" />
  </svg>
);

export const FlagIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M5 17V3M5 4h9l-2.5 3L14 10H5" />
  </svg>
);

export const EditIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M13.5 3.5l3 3L7 16l-4 1 1-4 9.5-9.5z" />
  </svg>
);

export const TrashIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M4 6h12M8 6V4.5A1.5 1.5 0 019.5 3h1A1.5 1.5 0 0112 4.5V6m-6.5 0v9.5A1.5 1.5 0 007 17h6a1.5 1.5 0 001.5-1.5V6" />
    <path d="M8.3 9v5M11.7 9v5" />
  </svg>
);

export const PinIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M9 3.5l7.5 7.5-3 1-3.5 4-1-4-4.5 4.5.5-.5 4-4.5-4-1 4-3.5z" />
  </svg>
);

export const DotsIcon = (p: IconProps) => (
  <svg {...base} {...p} fill="currentColor" stroke="none">
    <circle cx="4.5" cy="10" r="1.4" />
    <circle cx="10" cy="10" r="1.4" />
    <circle cx="15.5" cy="10" r="1.4" />
  </svg>
);

export const XIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M5 5l10 10M15 5L5 15" />
  </svg>
);

export const PaperclipIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M14.5 7.5l-6 6a2.8 2.8 0 104 4l6.2-6.2a4.6 4.6 0 00-6.5-6.5L5.8 11.2a6.4 6.4 0 009 9" />
  </svg>
);

export const MicIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <rect x="7.5" y="3" width="5" height="9" rx="2.5" />
    <path d="M5 9.5a5 5 0 0010 0M10 14.5V17M7.5 17h5" />
  </svg>
);

export const FileIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M6 3h5.5L15 6.5V17H6V3z" />
    <path d="M11.5 3v3.5H15" />
  </svg>
);

export const SunIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <circle cx="10" cy="10" r="3.3" />
    <path d="M10 2.5v2M10 15.5v2M17.5 10h-2M4.5 10h-2M15.3 4.7l-1.4 1.4M6.1 13.9l-1.4 1.4M15.3 15.3l-1.4-1.4M6.1 6.1L4.7 4.7" />
  </svg>
);

export const MoonIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M16.5 12.3A6.8 6.8 0 117.7 3.5a5.4 5.4 0 008.8 8.8z" />
  </svg>
);

export const LaptopIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <rect x="3.5" y="4" width="13" height="9" rx="1.3" />
    <path d="M2 16.5h16" />
  </svg>
);

export const ChevronDownIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M5 7.5l5 5 5-5" />
  </svg>
);

export const ChevronRightIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M7.5 5l5 5-5 5" />
  </svg>
);

export const LogOutIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M8 17H5.5A1.5 1.5 0 014 15.5v-11A1.5 1.5 0 015.5 3H8" />
    <path d="M12.5 14l4-4-4-4M16 10H7.5" />
  </svg>
);

export const SettingsIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <circle cx="10" cy="10" r="2.6" />
    <path d="M10 2.5v2M10 15.5v2M17.5 10h-2M4.5 10h-2M15.5 4.5l-1.4 1.4M5.9 14.1l-1.4 1.4M15.5 15.5l-1.4-1.4M5.9 5.9L4.5 4.5" />
  </svg>
);

export const UserIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <circle cx="10" cy="7" r="3" />
    <path d="M3.5 17a6.5 6.5 0 0113 0" />
  </svg>
);

export const AlertIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M10 3l8 14H2z" />
    <path d="M10 8.3v3.4" />
    <circle cx="10" cy="14.3" r="0.15" fill="currentColor" />
  </svg>
);

export const SparkleIcon = (p: IconProps) => (
  <svg {...base} {...p} fill="currentColor" stroke="none">
    <path d="M10 2l1.6 5.3L17 9l-5.4 1.7L10 16l-1.6-5.3L3 9l5.4-1.7z" />
  </svg>
);

export const EyeOffIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M3 3l14 14M8.3 8.5a2.4 2.4 0 003.3 3.3M6.1 6.2C4 7.5 2.5 9.6 2.5 10c0 .6 3 5.5 7.5 5.5 1.4 0 2.6-.4 3.7-1M9.9 4.5c3.9-.2 6.9 3.5 7.6 5.5-.3.8-1.2 2.4-2.6 3.7" />
  </svg>
);

export const EyeIcon = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M2.5 10S5.5 4.5 10 4.5 17.5 10 17.5 10 14.5 15.5 10 15.5 2.5 10 2.5 10z" />
    <circle cx="10" cy="10" r="2.3" />
  </svg>
);
