'use client';

import { cloneElement, isValidElement, useId, useState } from 'react';
import { cn } from '@/lib/utils';

export function Tooltip({
  label,
  children,
  side = 'top'
}: {
  label: string;
  children: React.ReactElement<any>;
  side?: 'top' | 'bottom';
}) {
  const [visible, setVisible] = useState(false);
  const id = useId();

  const trigger = isValidElement(children) ? cloneElement(children, { 'aria-describedby': id } as any) : children;

  return (
    <span
      className="relative inline-flex"
      onMouseEnter={() => setVisible(true)}
      onMouseLeave={() => setVisible(false)}
      onFocus={() => setVisible(true)}
      onBlur={() => setVisible(false)}
    >
      {trigger}
      {visible && (
        <span
          id={id}
          role="tooltip"
          className={cn(
            'pointer-events-none absolute start-1/2 z-50 -translate-x-1/2 whitespace-nowrap rounded-md bg-ink px-2 py-1 text-xs font-medium text-canvas animate-fade-in',
            side === 'top' ? 'bottom-full mb-1.5' : 'top-full mt-1.5'
          )}
        >
          {label}
        </span>
      )}
    </span>
  );
}
