'use client';

import { useToast } from '@/contexts/toast-context';
import { cn } from '@/lib/utils';
import { CheckIcon, AlertIcon, XIcon } from './icons';

export function Toaster() {
  const { toasts, dismissToast } = useToast();

  if (toasts.length === 0) return null;

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-4 z-[60] flex flex-col items-center gap-2 px-4 sm:bottom-6">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          role="status"
          className={cn(
            'pointer-events-auto flex w-full max-w-sm items-center gap-2 rounded-xl border border-border bg-surface px-3.5 py-2.5 text-sm text-ink shadow-lg animate-slide-up'
          )}
        >
          {toast.variant === 'success' && <CheckIcon className="h-4 w-4 shrink-0 text-accent" />}
          {toast.variant === 'error' && <AlertIcon className="h-4 w-4 shrink-0 text-danger" />}
          <span className="flex-1">{toast.message}</span>
          <button
            onClick={() => dismissToast(toast.id)}
            aria-label="Dismiss"
            className="shrink-0 rounded p-0.5 text-muted hover:text-ink"
          >
            <XIcon className="h-3.5 w-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
}
