'use client';

import { cn } from '@/lib/utils';

export function Switch({
  checked,
  onChange,
  label
}: {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={cn(
        'relative h-6 w-11 shrink-0 rounded-full transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-accent',
        checked ? 'bg-accent' : 'bg-surface-raised border border-border'
      )}
    >
      <span
        className={cn(
          'absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform duration-150 rtl:right-0.5 ltr:left-0.5',
          checked && 'rtl:-translate-x-5 ltr:translate-x-5'
        )}
      />
    </button>
  );
}
